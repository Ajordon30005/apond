# Independent Mind-HVP site

This project publishes the separate Mind-HVP copy, not a forwarding URL to the teacher's task computer. The original Marvosa repository and live teaching session remain untouched. The native mind, processor, memory, arithmetic, reinforcement, decay, generation and halting source files remain byte-identical to the supplied working copy.

The hosted application uses one resident native worker. The existing loader and atomic save organ still handle its line locally; the hosting adapter stores those exact completed checkpoint bytes in durable managed storage and restores them verbatim before invoking the same loader. It does not add a new memory codec, replay chat history or serialize another mind. Durable database locking prevents overlapping deployments from writing the same native checkpoint.

Private chat display history and attachment/generated-file bytes use separate durable hosting storage. They are UI/transport records only. All file types are sent through the declared reversible byte boundary, and response parts are rendered only when actually emitted. Full verified returned bytes remain downloadable. No additional AI, speech model or generator is inserted.

Open the permanent URL from the successful publication receipt and sign in with Manus. The project remains private under the platform owner-access policy. The application separately validates the project session, expiry and CSRF; no password or new provider account is required. The original teaching session is not exposed or connected to this site.

The always-on declaration was explicitly confirmed. Its deployed effect must be verified after publication. Hosting is metered; the approved default rates were disclosed before confirmation. The package's older portable launch guide still applies to a separately self-hosted copy; this managed deployment instead uses Dockerfile, service.py, managed_auth.py and managed_store.py with platform-provided runtime credentials.
