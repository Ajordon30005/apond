# HVP-PART/1: byte-boundary contract

This is a web transport format, not a new tokenizer, model, learning law or HVP equation. The special tokens are ordinary byte sequences sent through the existing processor. No vocabulary rows or mind code are added. The mind can encounter these segments through its existing experience path; the wrapper recognizes well-formed segments at delivery.

A part is the exact concatenation:

```text
<|hvp_part|> M:METADATA P:PAYLOAD <|hvp_end|>
```

`M` and `P` are ASCII decimal byte lengths of the encoded metadata and payload. Each displayed separator is exactly one ASCII space. Metadata is compact UTF-8 JSON containing `protocol: "HVP-PART/1"`, `role: "user"` or `"assistant"`, `kind: "text"`, `"file"`, `"audio"` or `"video"`, `name`, `mime`, and `n_bytes`, the original payload length.

Inside metadata and payload, byte `0x1b` is quoted as `0x1b 0x45` and byte `0x20` as `0x1b 0x53`. Every other byte is unchanged. This quoting is reversible for every byte sequence, including NULs, invalid UTF-8, repeated spaces, literal sentinels and escape bytes. It is necessary because the unchanged native mind views words at byte 32 and rejoins them with one space. Encoded frame interiors therefore have no byte 32; the source word view preserves the complete frame. The decoder reads declared lengths, not occurrences of delimiter strings within files. It never guesses, repairs or silently drops malformed payload bytes.

Ordinary text-only turns call the existing `MindHVP.interact()` unchanged. A turn with attachments combines all user-role frames into one byte sequence, followed by the actual prompt in the mind's existing normalized text form. Putting the prompt last leaves its words as the active context rather than ending the prompt on a file-control token. The single sequence then follows the existing organs in the same interaction order:

```text
juj.bytes_to_braid
→ mind._train_native
→ mind.generate_native
→ mind.experience_cycle
→ mind_hvp._hvp of the resulting braid
→ juj.hvp_to_bytes(verify=True)
→ mind.save
```

No byte-to-text decode is forced on the framed native route. The file content is presented in the declared reversible transport representation; it is not OCRed, summarized, base64-prompted or replaced by another AI. Text-only whitespace behavior stays the source's behavior.

At output the mind's existing generation includes its input and any continuation. User-role frames are consequently not advertised as generated artifacts. A strict assistant-role text part is decoded as UTF-8 and shown as text; strict assistant-role file/audio/video parts become private downloads, with passive audio/video controls where applicable. Multiple generated file parts additionally get one ZIP download; safe relative project paths are retained, and no file is executed or extracted by the service. Byte-invalid text becomes a downloadable binary part, not replacement characters. A complete `response.bin` is always available independently of rendering. Malformed framing is retained in the raw output and displayed as text or bytes rather than falsely reported as a valid generated file.

The wrapper only parses what is actually emitted. Framing support does not claim that this particular student already knows how to generate a new video, spoken recording, PDF or project. It supplies the input and output surfaces for that experience without substituting a generator.

To create a byte-exact part for a lesson or client:

```python
from pathlib import Path
from service import pack_part, unpack_part

raw = Path("example.pdf").read_bytes()
part = pack_part(raw, role="assistant", kind="file",
                 name="example.pdf", mime="application/pdf")
metadata, recovered, end = unpack_part(part)
assert recovered == raw and end == len(part)
```

Importing `service` does not start a listener or wake a mind. The example is a transport example, not a separate trainer. The web chat's Add file uses this same framing automatically for user attachments.
