"""Manus application authentication; independent of the native mind and store.

The platform's private-project gateway admits the owner/collaborators/invitees.
This module additionally authenticates the application session. Every verified
identity resolves to an independent member record; no identity is made owner.
Pending OAuth attempts are single-use, process-local, and lost safely on restart.
Use the resident service's single worker; callbacks must reach that same worker.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import ipaddress
import json
import math
import os
import re
import secrets
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, Request as URLRequest, build_opener

from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse, Response

COOKIE_NAME = 'webdev_app_session'
PENDING_COOKIE = 'mind_hvp_oauth_pending'
SESSION_SECONDS = 8 * 60 * 60
PENDING_SECONDS = 10 * 60


def _encode64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def _decode64(value: str) -> bytes:
    if not value or not re.fullmatch(r'[A-Za-z0-9_-]+', value):
        raise ValueError('Invalid base64url')
    return base64.b64decode(value + '=' * (-len(value) % 4), altchars=b'-_', validate=True)


def _object(raw: bytes) -> dict:
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON key')
            result[key] = value
        return result
    def reject_constant(_):
        raise ValueError('Invalid number')
    value = json.loads(raw.decode('utf-8'), object_pairs_hook=unique,
                       parse_constant=reject_constant)
    if not isinstance(value, dict):
        raise ValueError('Expected JSON object')
    return value


def _json(value: dict) -> bytes:
    return json.dumps(value, ensure_ascii=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def _expiry(value, now: float) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and value > now


def _origin(value: str) -> str:
    """Accept a literal browser origin, never a path or untrusted proxy header."""
    if not isinstance(value, str) or not value or len(value) > 2048:
        raise ValueError('Invalid origin')
    if any(ord(ch) <= 32 or ord(ch) == 127 for ch in value) or any(ch in value for ch in '\\%?#'):
        raise ValueError('Invalid origin')
    parsed = urlsplit(value)
    if (parsed.scheme not in ('http', 'https') or not parsed.netloc or parsed.path
            or parsed.query or parsed.fragment or parsed.username is not None
            or parsed.password is not None or parsed.netloc.endswith(':')):
        raise ValueError('Expected an HTTP(S) origin without credentials or a path')
    host = parsed.hostname
    port = parsed.port  # Also rejects malformed/out-of-range ports.
    if not host or (port is not None and not 1 <= port <= 65535):
        raise ValueError('Invalid host or port')
    try:
        address = ipaddress.ip_address(host)
        loopback = address.is_loopback
    except ValueError:
        labels = host.rstrip('.').split('.')
        if len(host) > 253 or not all(re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?', label) for label in labels):
            raise ValueError('Invalid hostname')
        loopback = host.lower() == 'localhost'
    if parsed.scheme == 'http' and not loopback:
        raise ValueError('Non-loopback origins require HTTPS')
    return value


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Never forward an authorization code/token to another URL.


class ManagedAuth:
    """Instantiate only in managed mode, then call install(app) once.

    session(request) returns csrf/openid/expires/user, or raises HTTPException(401).
    The parent still enforces same-origin and x-csrf-token on mutations. Member
    records grant access to this shared private workspace, not owner/admin rights.
    Private visibility must remain enforced by the platform, independently of us.
    """
    cookie_name = COOKIE_NAME
    oauth = True

    def __init__(self):
        names = ('MANUS_PROJECT_ID', 'MANUS_JWT_SECRET', 'MANUS_OAUTH_PORTAL_URL', 'MANUS_OAUTH_API_URL')
        values = {name: os.environ.get(name, '') for name in names}
        if any(not values[name] for name in names):
            raise RuntimeError('Managed authentication requires the supplied Manus OAuth environment')
        self.project_id = values['MANUS_PROJECT_ID']
        self._secret = values['MANUS_JWT_SECRET'].encode('utf-8')
        self.portal_url = self._base_url(values['MANUS_OAUTH_PORTAL_URL'])
        self.api_url = self._base_url(values['MANUS_OAUTH_API_URL'])
        self._guard = threading.RLock()
        self._pending = {}
        self._users = {}

    @staticmethod
    def _base_url(value: str) -> str:
        try:
            parsed = urlsplit(value)
            _origin(parsed.scheme + '://' + parsed.netloc)
            if parsed.query or parsed.fragment or any(ch in value for ch in '\\?#'):
                raise ValueError('Invalid base URL')
            if any(ord(ch) <= 32 or ord(ch) == 127 for ch in value):
                raise ValueError('Invalid base URL')
        except (ValueError, UnicodeError):
            raise RuntimeError('Invalid supplied Manus OAuth URL') from None
        return value.rstrip('/')

    def _mac(self, purpose: bytes, raw: bytes) -> bytes:
        return hmac.new(self._secret, purpose + raw, hashlib.sha256).digest()

    def _sign_session(self, identity: dict) -> str:
        now = int(time.time())
        claims = {'appId': self.project_id, 'openId': identity['openId'], 'iat': now,
                  'exp': now + SESSION_SECONDS}
        for key in ('name', 'email'):
            if key in identity:
                claims[key] = identity[key]
        body = _encode64(_json({'alg': 'HS256', 'typ': 'JWT'})) + '.' + _encode64(_json(claims))
        token = body + '.' + _encode64(self._mac(b'', body.encode('ascii')))
        if len(token) > 3800:
            raise HTTPException(502, 'Manus returned an identity too large for a session')
        return token

    def _claims(self, token: str) -> dict:
        try:
            if not isinstance(token, str) or len(token) > 16384:
                raise ValueError('Invalid token')
            head, body, signature = token.split('.')
            header = _object(_decode64(head))
            if header.get('alg') != 'HS256' or 'crit' in header:
                raise ValueError('Unsupported JWT')
            expected = self._mac(b'', (head + '.' + body).encode('ascii'))
            if not hmac.compare_digest(expected, _decode64(signature)):
                raise ValueError('Invalid signature')
            claims = _object(_decode64(body))
            if claims.get('appId') != self.project_id or not _expiry(claims.get('exp'), time.time()):
                raise ValueError('Expired or wrong-project session')
            if 'nbf' in claims and (type(claims['nbf']) not in (int, float)
                    or not math.isfinite(claims['nbf']) or claims['nbf'] > time.time()):
                raise ValueError('Session not yet valid')
            self._identity(claims)
            return claims
        except (ValueError, TypeError, UnicodeError, OverflowError, RecursionError):
            raise HTTPException(401, 'Please sign in with Manus') from None

    @staticmethod
    def _identity(value: dict) -> dict:
        openid = value.get('openId')
        if (not isinstance(openid, str) or not openid.strip() or len(openid) > 512
                or any(ord(ch) < 32 or ord(ch) == 127 for ch in openid)):
            raise ValueError('Missing or invalid Manus identity')
        identity = {'openId': openid}
        for key in ('name', 'email'):
            if key in value and value[key] is not None:
                if not isinstance(value[key], str) or len(value[key]) > 512:
                    raise ValueError('Invalid identity metadata')
                identity[key] = value[key]
        return identity

    def _resolve_user(self, identity: dict) -> dict:
        # Roles/permissions come from our user record, never caller JWT role claims.
        openid = identity['openId']
        with self._guard:
            record = self._users.setdefault(openid, {
                'openid': openid, 'role': 'member',
                'permissions': ('workspace:read', 'workspace:write')})
            for key in ('name', 'email'):
                if key in identity:
                    record[key] = identity[key]
            return dict(record)

    def session(self, request: Request) -> dict:
        token = request.cookies.get(COOKIE_NAME, '')
        claims = self._claims(token)
        user = self._resolve_user(self._identity(claims))
        csrf = _encode64(self._mac(b'mind-hvp:csrf:v1\0', token.encode('ascii')))
        return {'csrf': csrf, 'openid': user['openid'], 'expires': claims['exp'],
                'app_id': self.project_id, 'user': user}

    def _pending_token(self, pending: dict) -> str:
        body = _encode64(_json(pending))
        return body + '.' + _encode64(self._mac(b'mind-hvp:oauth-pending:v1\0', body.encode('ascii')))

    def _consume_state(self, request: Request) -> str:
        try:
            states = request.query_params.getlist('state')
            if len(states) != 1 or not states[0] or len(states[0]) > 8192:
                raise ValueError('Invalid state')
            state = _object(base64.b64decode(states[0].encode('ascii'), validate=True))
            token = request.cookies.get(PENDING_COOKIE, '')
            if not token or len(token) > 8192:
                raise ValueError('Missing pending cookie')
            body, signature = token.split('.')
            expected = self._mac(b'mind-hvp:oauth-pending:v1\0', body.encode('ascii'))
            if not hmac.compare_digest(expected, _decode64(signature)):
                raise ValueError('Invalid pending cookie')
            pending = _object(_decode64(body))
            nonce = pending.get('nonce')
            redirect_uri = pending.get('redirectUri')
            if (not isinstance(nonce, str) or not isinstance(state.get('nonce'), str)
                    or not hmac.compare_digest(nonce, state['nonce'])
                    or not isinstance(redirect_uri, str) or state.get('redirectUri') != redirect_uri
                    or not _expiry(pending.get('exp'), time.time())):
                raise ValueError('Mismatched or expired state')
            if not redirect_uri.endswith('/auth/callback'):
                raise ValueError('Invalid callback')
            _origin(redirect_uri[:-len('/auth/callback')])
            with self._guard:
                attempt = self._pending.pop(nonce, None)  # Consume before exchange, even on failure.
            if not attempt or attempt != pending:
                raise ValueError('Expired or already used state')
            return redirect_uri
        except (ValueError, TypeError, UnicodeError, OverflowError, RecursionError):
            raise HTTPException(400, 'Sign-in expired or could not be verified. Start again.') from None

    def _post_json(self, method: str, payload: dict, timeout: int) -> dict:
        url = self.api_url + '/webdev.v1.WebDevAuthPublicService/' + method
        request = URLRequest(url, data=_json(payload), method='POST', headers={
            'Content-Type': 'application/json', 'Accept': 'application/json',
            'connect-protocol-version': '1'})
        try:
            with build_opener(_NoRedirect()).open(request, timeout=timeout) as response:
                raw = response.read(1024 * 1024 + 1)
                if not 200 <= response.status < 300 or len(raw) > 1024 * 1024:
                    raise ValueError('Invalid OAuth response')
                result = _object(raw)
                if 'error' in result and result['error'] is not None:
                    raise ValueError('OAuth API reported an error')
                return result
        except HTTPError as exc:
            # Read but never print/reflect provider bodies, tokens, codes, or secrets.
            try:
                exc.read(1024 * 1024)
            except OSError:
                pass
            finally:
                exc.close()
            raise HTTPException(502, 'Manus sign-in was rejected. Start again.') from None
        except (URLError, OSError, ValueError, TypeError, UnicodeError, RecursionError):
            raise HTTPException(502, 'Could not complete Manus sign-in. Start again.') from None

    def login(self, request: Request) -> Response:
        origins = request.query_params.getlist('origin')
        try:
            if len(origins) != 1:
                raise ValueError('Expected one origin')
            redirect_uri = _origin(origins[0]) + '/auth/callback'
        except (ValueError, UnicodeError):
            raise HTTPException(400, 'Provide the actual HTTP(S) browser origin without a path') from None
        now = int(time.time())
        pending = {'nonce': secrets.token_urlsafe(32), 'redirectUri': redirect_uri,
                   'exp': now + PENDING_SECONDS}
        with self._guard:
            self._pending = {key: value for key, value in self._pending.items() if _expiry(value['exp'], now)}
            if len(self._pending) >= 2048:
                raise HTTPException(503, 'Too many pending sign-ins. Try again shortly.')
            self._pending[pending['nonce']] = pending
        state = base64.b64encode(_json({'redirectUri': redirect_uri, 'nonce': pending['nonce']})).decode('ascii')
        query = urlencode({'appId': self.project_id, 'redirectUri': redirect_uri,
                           'state': state, 'responseType': 'code'})
        response = RedirectResponse(self.portal_url + '/app-auth?' + query, status_code=302)
        response.set_cookie(PENDING_COOKIE, self._pending_token(pending), max_age=PENDING_SECONDS,
                            path='/auth', secure=True, httponly=True, samesite='none')
        response.headers['Cache-Control'] = 'no-store'
        response.headers['Referrer-Policy'] = 'no-referrer'
        return response

    def callback(self, request: Request) -> Response:
        try:
            redirect_uri = self._consume_state(request)
            codes = request.query_params.getlist('code')
            if (len(codes) != 1 or not codes[0] or len(codes[0]) > 8192
                    or 'error' in request.query_params):
                raise HTTPException(400, 'Manus sign-in did not return an authorization code. Start again.')
            exchange = self._post_json('ExchangeToken', {
                'clientId': self.project_id, 'grantType': 'authorization_code',
                'code': codes[0], 'redirectUri': redirect_uri}, timeout=60)
            access_token = exchange.get('accessToken')
            if not isinstance(access_token, str) or not access_token or exchange.get('tokenType') != 'Bearer':
                raise HTTPException(502, 'Manus did not return a valid access token')
            info = self._post_json('GetUserInfo', {'accessToken': access_token}, timeout=30)
            try:
                identity = self._identity(info)
            except ValueError:
                raise HTTPException(502, 'Manus did not return a valid identity') from None
            token = self._sign_session(identity)
            self._resolve_user(identity)
            response = RedirectResponse('/', status_code=303)  # No arbitrary return URL.
            response.set_cookie(COOKIE_NAME, token, max_age=SESSION_SECONDS, path='/',
                                secure=True, httponly=True, samesite='none')
        except HTTPException as exc:
            response = JSONResponse({'detail': exc.detail}, status_code=exc.status_code)
        response.delete_cookie(PENDING_COOKIE, path='/auth', secure=True, httponly=True, samesite='none')
        response.headers['Cache-Control'] = 'no-store'
        response.headers['Referrer-Policy'] = 'no-referrer'
        return response

    def clear(self, response: Response) -> None:
        """Parent's CSRF-protected POST /api/logout clears the real cookie."""
        response.delete_cookie(COOKIE_NAME, path='/', secure=True, httponly=True, samesite='none')
        response.delete_cookie(PENDING_COOKIE, path='/auth', secure=True, httponly=True, samesite='none')
        response.headers['Cache-Control'] = 'no-store'

    def install(self, app) -> None:
        app.add_api_route('/auth/login', self.login, methods=['GET'], include_in_schema=False)
        app.add_api_route('/auth/callback', self.callback, methods=['GET'], include_in_schema=False)
