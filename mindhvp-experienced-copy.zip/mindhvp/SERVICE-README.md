# Mind-HVP private web service

This is the separate `mind-hvp-web-service` branch and complete copied repository. The original teaching conversation and original repository remain untouched. `service.py` is the complete new service file with its chat interface embedded. The copied source mind, processor, memory, arithmetic, learning, reinforcement, decay and halting are unchanged.

## Run it yourself

Unzip the complete package into a directory you control. Python 3.12 is the tested runtime. On macOS/Linux, from that directory:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-service.txt
.venv/bin/python service.py
```

On Windows:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -r requirements-service.txt
.venv\Scripts\python service.py
```

The launcher asks you to choose your private chat password; it does not store the password in source or chat history. Open `http://127.0.0.1:8765` on that computer and sign in. You can instead set `MIND_HVP_PASSWORD` in your own runtime environment. Do not commit that password or put it in a public URL.

The web boundary requires FastAPI, Uvicorn and python-multipart. NumPy is also declared because the existing `mst_equation → collapse_calc` import already requires it, not because the service replaces the mind with a standard model. All import roots are resolved from the copied repository, including `hcl_stack`, `hcl-ai/engine` and `hcl-ai/mind`. Keep the whole directory together. No API key, paid model or external speech provider is used.

## Use from your phone or another device

Nothing was launched or published in the Manus cloud. The service needs to run on a computer or independently chosen host that you keep online. For access from other devices, give that host an HTTPS endpoint or use your existing private network with HTTPS. The local-only default is deliberate: it does not expose your evolving mind or file attachments to public HTTP.

For your own domain with Caddy on your chosen host, point its DNS at that host, set `MIND_HVP_DOMAIN` to the real domain for Caddy, and run the mind with secure cookies:

```bash
.venv/bin/python service.py --secure-cookie
# Separately, on the same chosen host with Caddy installed:
caddy run --config Caddyfile.service --adapter caddyfile
```

Caddy serves HTTPS and reverse-proxies to `127.0.0.1:8765`. Permit only the necessary HTTPS/TLS ports on that host; do not expose the internal HTTP listener publicly. The browser then uses your domain on any of your devices. DNS, the host and its network access must be supplied on your own deployment; there is no invented public URL in this package.

Direct TLS is also supported with `--host 0.0.0.0 --cert /your/certificate.pem --key /your/private-key.pem`. The launcher refuses non-local binding without secure-cookie/TLS configuration. For a separately chosen container host, `Dockerfile.service` supplies the same source and dependencies; mount a durable writable volume at `/app/service-data`, set `MIND_HVP_PASSWORD` privately, and put its listener behind HTTPS. Run only one container replica and one server worker for a given data directory.

## Chat and attachments

The interface provides a responsive chat layout, display threads, Add file, drag-and-drop, multiple attachment chips, queued/thinking states, and private response downloads. All types of attached files are delivered as bytes, not silently converted to text. Its first prompt with attachments is one byte sequence containing length-framed user file segments and the actual prompt. The prompt is last so it remains the native mind's active trailing context. The processor's existing `bytes_to_braid` and verified inverse are used; the original organs perform the learning and generation.

Special boundary tokens are ordinary bytes. A minimal reversible escape for space and ESC inside frame interiors preserves binary data through the mind's existing word-space view. Delimiters inside payloads cannot terminate a frame because lengths, not substring splitting, identify its boundaries. `SERVICE-PROTOCOL.md` contains the complete public format and examples.

Text-only messages call the original `interact()` method unchanged. A new display chat does not reset or clone the resident mind. Every accepted turn is experience; all turns use one worker and preserve order. The service does not impose response-token, generated-byte or turn-length caps. Waiting for a response is not fake streaming or a reason to replay it. Closing the browser does not cancel a queued/running turn; reopening the display thread lets you see its state and completed result.

The output renderer separates correctly framed generated text, files, audio and video; passive audio/video has browser controls. Multiple generated files also produce a single ZIP while retaining safe relative project paths. Generated code and archives are not executed or extracted. Input-prefix segments, even assistant-role examples typed as a lesson, are not advertised as newly generated artifacts. A complete unmodified `response.bin` download preserves the whole verified returned sequence even when its framing is incomplete or its bytes are not UTF-8.

This supplies the surfaces for future learned file, voice and project output. It does not substitute a video/voice/code generator for the existing student or claim those abilities have already been taught. An uploaded audio recording is another byte attachment; a supported emitted audio part is playable. No transcript model or TTS provider has been inserted into the mind.

## State and presentation storage

On first start only, `service-data/mind-hvp.line` is seeded from this branch's copied `hcl-ai/mind-hvp.line`. The service wakes that line using the original loader and saves through the original atomic save organ. Its wake/reconstruction behavior is exactly the existing mind's behavior; the wrapper adds no new checkpoint codec, serialized path dictionary or hidden replay trainer.

The same process holds the live mind between messages. `service-data/chat.sqlite3` and `service-data/artifacts/` are private display history and file-delivery storage only, not mind memory. They are never fed back on startup. The single data-directory lock refuses a second writer. Queued, not-yet-experienced requests can resume; interrupted running requests are marked failed rather than automatically replayed after they may have affected the mind. Retry IDs prevent accidental duplicate experience after an uncertain network response. Normal server shutdown waits for the current native turn to finish and then invokes the source save.

Keep `service-data/` on durable storage and back it up when the process is stopped or with the host's proper snapshot method. Keep access to the copied repository and data directory private. Password login uses HttpOnly cookies, explicit CSRF checks, same-origin mutation checks and secure cookies for remote HTTPS use. Do not run a second external worker against the same checkpoint.

## What was checked

Without opening a network listener, the boundary was checked in process for every byte value, repeated spaces, ESC, literal sentinels, private authentication/CSRF, ordinary text passthrough, attached-byte delivery, file downloads, project ZIP paths, complete raw output and retry idempotence. The actual copied native imports and organ route also completed on an isolated temporary checkpoint: integrity intact and binary attachment exact. No original teaching input, source file or checkpoint was modified by these checks. The UI JavaScript is syntax-checked separately; no browser-hosted cloud service is required for that check.

`check-service.py` is a boundary-only fixture, never a model fallback. If you wish to run it, additionally install `httpx` in your own virtual environment. The normal service does not depend on that test fixture or on `httpx`.

`SOURCE-PRESERVATION.json` inventories the copied original files. The complete original repository is retained, including the original README, documentation, skills and existing other-model artifacts. The service never loads those other models. The local service branch is included in the package; no remote repository push was made.

Boundary references: [FastAPI request files](https://fastapi.tiangolo.com/tutorial/request-files/) and [MDN secure cookie configuration](https://developer.mozilla.org/en-US/docs/Web/Security/Practical_implementation_guides/Cookies).
