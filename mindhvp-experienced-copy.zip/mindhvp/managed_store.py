"""Managed transport persistence; no native mind code or serialization lives here.

Import this module from Runtime only after service.Store has been defined. All
SQL is parameterized, and migrations are additive. Ordinary DB reconnection is
allowed only between transactions; a failed write/commit is never replayed.
The separate resident connection NEVER reconnects itself.
"""
from __future__ import annotations

import os
from pathlib import Path
import re
import json
import ssl
import tempfile
import threading
from urllib.parse import parse_qs, unquote, urlsplit
from typing import Any

import pymysql
from pymysql.cursors import DictCursor, SSDictCursor
from service import Store


CHUNK_BYTES = 1024 * 1024
RESIDENT_LOCK = 'mind-hvp-resident'
_UUID = re.compile(r'[0-9a-f]{32}\Z')
_COLUMNS = {
    'chats': ('id', 'title', 'updated_at'),
    'messages': ('id', 'chat_id', 'role', 'parts', 'status', 'created_at',
                 'job_id', 'verdict', 'error', 'raw_url', 'project_url'),
    'jobs': ('id', 'chat_id', 'client_id', 'status', 'prompt', 'uploads',
             'created_at', 'error', 'verdict'),
    'artifacts': ('id', 'path', 'name', 'mime', 'size'),
}
_SCHEMA = {
    'chats': {
        'rowid': 'BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY',
        'id': 'VARCHAR(64) NOT NULL', 'title': 'LONGTEXT NOT NULL',
        'updated_at': 'DOUBLE NOT NULL',
    },
    'messages': {
        'rowid': 'BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY',
        'id': 'VARCHAR(64) NOT NULL', 'chat_id': 'VARCHAR(64) NOT NULL',
        'role': 'LONGTEXT NOT NULL', 'parts': 'LONGTEXT NOT NULL',
        'status': 'LONGTEXT NOT NULL', 'created_at': 'DOUBLE NOT NULL',
        'job_id': 'VARCHAR(64) NULL', 'verdict': 'LONGTEXT NULL',
        'error': 'LONGTEXT NULL', 'raw_url': 'LONGTEXT NULL',
        'project_url': 'LONGTEXT NULL',
    },
    'jobs': {
        'rowid': 'BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY',
        'id': 'VARCHAR(64) NOT NULL', 'chat_id': 'VARCHAR(64) NOT NULL',
        'client_id': 'VARCHAR(191) NOT NULL', 'status': 'LONGTEXT NOT NULL',
        'prompt': 'LONGTEXT NOT NULL', 'uploads': 'LONGTEXT NOT NULL',
        'created_at': 'DOUBLE NOT NULL', 'error': 'LONGTEXT NULL',
        'verdict': 'LONGTEXT NULL',
    },
    'artifacts': {
        'rowid': 'BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY',
        'id': 'VARCHAR(64) NOT NULL', 'path': 'LONGTEXT NOT NULL',
        'name': 'LONGTEXT NOT NULL', 'mime': 'LONGTEXT NOT NULL',
        'size': 'BIGINT NOT NULL',
    },
    'artifact_chunks': {
        'artifact_id': 'VARCHAR(64) NOT NULL', 'seq': 'INT UNSIGNED NOT NULL',
        'payload': 'LONGBLOB NOT NULL',
    },
    'transport_checkpoints': {
        'singleton': 'TINYINT UNSIGNED NOT NULL PRIMARY KEY',
        'line': 'LONGBLOB NOT NULL',
    },
}
_UNIQUE: dict[str, list[tuple[str, ...]]] = {table: [('id',)] for table in _COLUMNS}
_UNIQUE['jobs'].append(('client_id',))
_UNIQUE['artifact_chunks'] = [('artifact_id', 'seq')]
_UNIQUE['transport_checkpoints'] = [('singleton',)]


class ResidentLostError(RuntimeError):
    """The native resident must stop; rebuild it before explicitly reacquiring."""


def _bool(value):
    if value.lower() in ('true', '1', 'yes', 'on'):
        return True
    if value.lower() in ('false', '0', 'no', 'off'):
        return False
    raise ValueError('Invalid boolean database option')


def _connection_options(url):
    if not url:
        raise RuntimeError('DATABASE_URL is required for managed persistence')
    parsed = urlsplit(url)
    if parsed.scheme not in ('mysql', 'mysql+pymysql') or not parsed.hostname:
        raise ValueError('DATABASE_URL must be a MySQL URL')
    database = unquote(parsed.path.lstrip('/'))
    if not database or '/' in database:
        raise ValueError('DATABASE_URL must name one database')
    query = parse_qs(parsed.query, keep_blank_values=True)

    def option(name, default=None):
        values = query.get(name)
        return values[-1] if values else default

    options: dict[str, Any] = dict(host=parsed.hostname, port=parsed.port or 3306,
                   user=unquote(parsed.username or ''),
                   password=unquote(parsed.password or ''), database=database,
                   charset='utf8mb4', cursorclass=DictCursor, autocommit=False)
    for key, default in (('connect_timeout', 10), ('read_timeout', 60),
                         ('write_timeout', 60)):
        value = int(option(key, str(default)))
        if value <= 0:
            raise ValueError('Database timeouts must be positive')
        options[key] = value

    # Explicit ssl=false/ssl-mode=DISABLED is honored. Otherwise TLS uses
    # system trust and hostname verification by default, never silent fallback.
    mode = option('ssl_mode', option('ssl-mode', option('sslmode')))
    mode = mode.lower().replace('-', '_') if mode else None
    raw_ssl = option('ssl')
    ssl_settings = {}
    if raw_ssl is not None and raw_ssl.lstrip().startswith('{'):
        ssl_settings = json.loads(raw_ssl)
        if not isinstance(ssl_settings, dict):
            raise ValueError('Database TLS options must be an object')
        enabled = True
    else:
        enabled = _bool(raw_ssl) if raw_ssl is not None else mode != 'disabled'
    if mode not in (None, 'disabled', 'required', 'verify_ca', 'verify_identity'):
        raise ValueError('Unsupported database TLS mode; choose an explicit secure or disabled mode')
    if mode == 'disabled':
        enabled = False
    if not enabled:
        if any(option(key) is not None for key in ('ssl_ca', 'ssl_cert', 'ssl_key')):
            raise ValueError('TLS files supplied while database TLS is disabled')
        return options, False

    context = ssl.create_default_context(cafile=option('ssl_ca'))
    if ssl_settings.get('ca'):
        context.load_verify_locations(cadata=ssl_settings['ca'])
    if ssl_settings.get('rejectUnauthorized') is False:
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    if mode == 'required':
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    elif mode == 'verify_ca':
        context.check_hostname = False
    verify = option('ssl_verify_cert')
    if verify is not None:
        if not _bool(verify):
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        else:
            context.verify_mode = ssl.CERT_REQUIRED
    hostname = option('ssl_check_hostname', option('ssl_verify_identity'))
    if hostname is not None:
        context.check_hostname = _bool(hostname)
    cert, key = option('ssl_cert'), option('ssl_key')
    if key and not cert:
        raise ValueError('Database TLS key requires a certificate')
    if cert:
        context.load_cert_chain(cert, key)
    options['ssl'] = context
    return options, True


def _translate(sql):
    # SQLite's INSERT ... VALUES lacks column names: explicitly omit rowid.
    match = re.match(r'\s*INSERT\s+INTO\s+(`?)(chats|messages|jobs|artifacts)\1\s+(?=VALUES\s*\()',
                     sql, flags=re.I)
    if match:
        table = match.group(2).lower()
        sql = sql[:match.end()] + '(' + ','.join(_COLUMNS[table]) + ') ' + sql[match.end():]
    # Convert only unquoted qmarks; escape literal percent signs for PyMySQL's
    # parameter interpolation. Preserve quoted strings/identifiers verbatim.
    result, quote, index = [], None, 0
    while index < len(sql):
        char = sql[index]
        if char == '%':
            result.append('%%')
        elif quote:
            result.append(char)
            if char == '\\' and index + 1 < len(sql):
                index += 1
                escaped = sql[index]
                result.append('%%' if escaped == '%' else escaped)
            elif char == quote:
                if index + 1 < len(sql) and sql[index + 1] == quote:
                    result.append(quote)
                    index += 1
                else:
                    quote = None
        elif char in ("'", '"', '`'):
            quote = char
            result.append(char)
        else:
            result.append('%s' if char == '?' else char)
        index += 1
    return ''.join(result)


class _Database:
    """SQLite-like connection boundary, including direct multi-statement calls.

    Caller must hold Store.guard around a transaction and call rollback() if
    any statement fails. No reconnect/retry is possible inside a transaction.
    """
    def __init__(self, connect, guard, on_close):
        self._connect, self._guard, self._on_close = connect, guard, on_close
        self._connection = None
        self.in_transaction = False
        self._failed = self._closed = False

    def _ready(self):
        if self._closed:
            raise RuntimeError('Managed store is closed')
        if self._failed:
            raise RuntimeError('Database transaction failed; rollback is required')
        if self._connection is None:
            self._connection = self._connect()
        else:
            self._connection.ping(reconnect=not self.in_transaction)
            # ping's reconnect bypasses our connector, so recheck TLS.
            if getattr(self._connect, 'tls_required', False) and not self._connection._secure:
                self._connection.close()
                self._connection = None
                raise RuntimeError('Database connection did not negotiate required TLS')

    def execute(self, sql, params=(), *, cursorclass=None):
        with self._guard:
            cursor = None
            try:
                self._ready()
                assert self._connection is not None
                cursor = self._connection.cursor(cursorclass) if cursorclass else self._connection.cursor()
                cursor.execute(_translate(sql), params)
                self.in_transaction = True
                return cursor
            except Exception:
                self._failed = True
                if cursor is not None:
                    try:
                        cursor.close()
                    except Exception:
                        pass
                raise

    def commit(self):
        with self._guard:
            if self._closed or self._failed:
                raise RuntimeError('Cannot commit a closed or failed database transaction')
            if self._connection is not None:
                try:
                    self._connection.commit()  # Never ping/reconnect/replay a commit.
                except Exception:
                    self._failed = True
                    raise
            self.in_transaction = False

    def rollback(self):
        with self._guard:
            if self._connection is not None:
                try:
                    self._connection.rollback()
                except Exception:
                    self._connection.close()
                    self._connection = None
            self.in_transaction = self._failed = False

    def close(self):
        with self._guard:
            if not self._closed:
                self._on_close()
                self.rollback()
                if self._connection is not None:
                    self._connection.close()
                self._connection = None
                self._closed = True


class ManagedStore(Store):
    def __init__(self, directory, database_url=None):
        self.directory = Path(directory).resolve()
        self.directory.mkdir(parents=True, exist_ok=True)
        (self.directory / 'artifacts').mkdir(exist_ok=True)
        if (self.directory / 'artifacts').resolve() != self.directory / 'artifacts':
            raise ValueError('Artifact directory must not be a symlink')
        self.guard = threading.RLock()
        self._options, self._tls_required = _connection_options(
            database_url if database_url is not None else os.environ.get('DATABASE_URL'))
        self._resident_connection = None
        self._resident_lost = False

        def connect():
            connection = pymysql.connect(**self._options)
            if self._tls_required and not getattr(connection, '_secure', False):
                connection.close()
                raise RuntimeError('Database connection did not negotiate required TLS')
            return connection

        setattr(connect, 'tls_required', self._tls_required)
        self._connect = connect
        self.db = _Database(connect, self.guard, self.release_resident)
        try:
            self.initialize()
        except Exception:
            self.db.close()
            raise

    def initialize(self):
        """Create missing schema/columns/unique keys only; never drop or rewrite."""
        with self.guard:
            for table, columns in _SCHEMA.items():
                definitions = [f'`{name}` {definition}' for name, definition in columns.items()]
                for key in _UNIQUE.get(table, []):
                    if key == ('singleton',):
                        continue  # already the primary key
                    names = ','.join(f'`{name}`' for name in key)
                    if table == 'artifact_chunks':
                        definitions.append(f'PRIMARY KEY ({names})')
                    else:
                        definitions.append(f'UNIQUE KEY `uq_{table}_{"_".join(key)}` ({names})')
                self.execute(f'CREATE TABLE IF NOT EXISTS `{table}` ({",".join(definitions)}) '
                             'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin')
                existing = {row['Field'] for row in self.rows(f'SHOW COLUMNS FROM `{table}`')}
                for name, definition in columns.items():
                    if name not in existing:
                        # A legacy table may already have an id primary key.
                        # Adding an auto-increment unique rowid preserves it.
                        if name == 'rowid':
                            definition = 'BIGINT NOT NULL AUTO_INCREMENT UNIQUE'
                        try:
                            self.execute(f'ALTER TABLE `{table}` ADD COLUMN `{name}` {definition}')
                        except pymysql.err.OperationalError as exc:
                            if exc.args[0] != 1060:  # concurrent additive migration
                                raise
                indices = {}
                for row in self.rows(f'SHOW INDEX FROM `{table}`'):
                    if not row['Non_unique']:
                        indices.setdefault(row['Key_name'], []).append((row['Seq_in_index'], row['Column_name']))
                keys = {tuple(name for _, name in sorted(items)) for items in indices.values()}
                for key in _UNIQUE.get(table, []):
                    if key not in keys:
                        names = ','.join(f'`{name}`' for name in key)
                        try:
                            self.execute(f'ALTER TABLE `{table}` ADD UNIQUE KEY '
                                         f'`uq_{table}_{"_".join(key)}` ({names})')
                        except pymysql.err.OperationalError as exc:
                            if exc.args[0] != 1061:
                                raise

    def execute(self, sql, params=()):
        with self.guard:
            try:
                # Clean durable chunks in the same transaction as the portable
                # wrapper's losing-attempt metadata DELETE (both path and id).
                deletion = re.fullmatch(r'\s*DELETE\s+FROM\s+`?artifacts`?\s+WHERE\s+`?(path|id)`?\s*=\s*\?\s*;?\s*',
                                        sql, flags=re.I)
                if deletion:
                    field = deletion.group(1).lower()
                    cursor = self.db.execute(f'SELECT id FROM artifacts WHERE `{field}`=? FOR UPDATE', params)
                    ids = [row['id'] for row in cursor.fetchall()]
                    cursor.close()
                    for aid in ids:
                        self.db.execute('DELETE FROM artifact_chunks WHERE artifact_id=?', (aid,)).close()
                cursor = self.db.execute(sql, params)
                self.db.commit()
                cursor.close()
                return cursor
            except Exception:
                self.db.rollback()
                raise

    def rows(self, sql, params=()):
        with self.guard:
            outer = self.db.in_transaction
            cursor = None
            try:
                cursor = self.db.execute(sql, params)
                result = [dict(row) for row in cursor.fetchall()]
                if not outer:
                    self.db.commit()  # end read snapshot, but preserve caller's transaction
                return result
            except Exception:
                if not outer:
                    self.db.rollback()
                raise
            finally:
                if cursor is not None:
                    cursor.close()

    def _artifact_identity(self, relative_or_id):
        value = str(relative_or_id)
        aid = value[len('artifacts/'):] if value.startswith('artifacts/') else value
        if not _UUID.fullmatch(aid) or value not in (aid, 'artifacts/' + aid):
            raise ValueError('Artifact path must be an exact UUID artifact path or ID')
        path = self.directory / 'artifacts' / aid
        if path.is_symlink() or (self.directory / 'artifacts').resolve() != self.directory / 'artifacts':
            raise ValueError('Artifact paths must not be symlinks')
        return aid, 'artifacts/' + aid, path

    def _idle(self):
        if self.db.in_transaction:
            raise RuntimeError('Durable file operations require a separate transaction')

    def artifact(self, data, name, mime):
        with self.guard:
            part = super().artifact(data, name, mime)
            aid = part['url'].rsplit('/', 1)[-1]
            try:
                self.persist_upload(aid)
            except Exception:
                try:
                    self.discard_upload(aid)
                except Exception:
                    pass  # preserve the original storage failure, never replay
                raise
            return part

    def persist_upload(self, relative):
        """Persist an immutable UUID file AFTER its artifact metadata was inserted."""
        aid, relative, path = self._artifact_identity(relative)
        with self.guard:
            self._idle()
            try:
                # Hold the metadata row lock through the complete chunk write.
                cursor = self.db.execute('SELECT path,size FROM artifacts WHERE id=? FOR UPDATE', (aid,))
                item = cursor.fetchone()
                cursor.close()
                if not item or item['path'] != relative:
                    raise FileNotFoundError('Artifact metadata is missing or invalid')
                self.db.execute('DELETE FROM artifact_chunks WHERE artifact_id=?', (aid,)).close()
                total = sequence = 0
                with path.open('rb') as source:
                    while True:
                        chunk = source.read(CHUNK_BYTES)
                        if not chunk and sequence:
                            break
                        self.db.execute('INSERT INTO artifact_chunks(artifact_id,seq,payload) VALUES(?,?,?)',
                                        (aid, sequence, chunk)).close()
                        total += len(chunk)
                        sequence += 1
                        if not chunk:
                            break
                if total != item['size']:
                    raise ValueError('Artifact byte count does not match metadata')
                self.db.commit()
            except Exception:
                self.db.rollback()
                raise
        return path

    def restore_artifact(self, relative_or_id):
        """Stream exact ordered transport chunks to an atomic, private local file."""
        aid, relative, path = self._artifact_identity(relative_or_id)
        with self.guard:
            self._idle()
            temporary = cursor = None
            try:
                cursor = self.db.execute('SELECT path,size FROM artifacts WHERE id=?', (aid,))
                item = cursor.fetchone()
                cursor.close()
                cursor = None
                if not item or item['path'] != relative:
                    raise FileNotFoundError('Artifact metadata is missing or invalid')
                cursor = self.db.execute('SELECT seq,payload FROM artifact_chunks WHERE artifact_id=? ORDER BY seq',
                                         (aid,), cursorclass=SSDictCursor)
                with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.' + aid + '-',
                                                 suffix='.tmp', delete=False) as target:
                    temporary = Path(target.name)
                    total = sequence = 0
                    for chunk in cursor:
                        payload = chunk['payload']
                        if chunk['seq'] != sequence or len(payload) > CHUNK_BYTES:
                            raise ValueError('Artifact chunks are incomplete or invalid')
                        target.write(payload)
                        total += len(payload)
                        sequence += 1
                    if not sequence or total != item['size']:
                        raise FileNotFoundError('Durable artifact bytes are incomplete')
                    target.flush()
                    os.fsync(target.fileno())
                cursor.close()
                cursor = None
                self.db.commit()
                os.replace(temporary, path)
                temporary = None
                return path
            except Exception:
                if cursor is not None:
                    cursor.close()
                    cursor = None
                self.db.rollback()
                raise
            finally:
                if temporary is not None:
                    temporary.unlink(missing_ok=True)

    def discard_upload(self, relative):
        aid, relative, path = self._artifact_identity(relative)
        self.execute('DELETE FROM artifacts WHERE path=?', (relative,))
        path.unlink(missing_ok=True)

    def read_checkpoint(self):
        """Return native checkpoint bytes verbatim, or None if never mirrored."""
        item = self.one('SELECT `line` FROM transport_checkpoints WHERE singleton=1')
        return bytes(item['line']) if item else None

    def acquire_resident(self):
        """Nonblocking claim; False means another deployment owns the mind.

        After a lost resident connection, stop/discard the native object and
        call release_resident() before an explicit reacquisition and reload.
        """
        with self.guard:
            if self._resident_lost:
                raise ResidentLostError('Resident ownership was lost; rebuild the resident before reacquiring')
            if self._resident_connection is not None:
                return self.is_resident()
            connection = self._connect()
            try:
                with connection.cursor() as cursor:
                    cursor.execute('SELECT GET_LOCK(%s,0) AS acquired', (RESIDENT_LOCK,))
                    acquired = cursor.fetchone()['acquired']
                connection.commit()
                if acquired == 1:
                    self._resident_connection = connection
                    return True
                if acquired == 0:
                    connection.close()
                    return False
                raise RuntimeError('Database could not acquire the resident lock')
            except Exception:
                try:
                    connection.close()
                except Exception:
                    pass
                raise

    def _lose_resident(self):
        connection = self._resident_connection
        self._resident_connection = None
        self._resident_lost = True
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass

    def _owned(self):
        connection = self._resident_connection
        if connection is None or self._resident_lost:
            return False
        with connection.cursor() as cursor:
            cursor.execute('SELECT IS_USED_LOCK(%s)=CONNECTION_ID() AS owned', (RESIDENT_LOCK,))
            return cursor.fetchone()['owned'] == 1

    def is_resident(self):
        """Check the original lock session, WITHOUT reconnecting on any error."""
        with self.guard:
            try:
                if not self._owned():
                    if self._resident_connection is not None:
                        self._lose_resident()
                    return False
                assert self._resident_connection is not None
                self._resident_connection.commit()
                return True
            except Exception:
                self._lose_resident()
                return False

    def mirror_checkpoint(self, path):
        """Mirror exact saved bytes using the lock-owning session itself.

        A lock check on a different connection would permit a stale owner to
        race a new deployment's checkpoint write. This write cannot reconnect
        and cannot succeed on a session that no longer owns its advisory lock.
        """
        with self.guard:
            try:
                if not self._owned():
                    raise ResidentLostError('Native checkpoint write requires resident ownership')
                data = Path(path).read_bytes()
                assert self._resident_connection is not None
                with self._resident_connection.cursor() as cursor:
                    cursor.execute('INSERT INTO transport_checkpoints(singleton,`line`) VALUES(1,%s) '
                                   'ON DUPLICATE KEY UPDATE `line`=VALUES(`line`)', (data,))
                self._resident_connection.commit()
            except Exception:
                # An uncertain checkpoint commit is never retried. The native
                # object must stop; a future owner reloads the durable bytes.
                self._lose_resident()
                raise

    def release_resident(self):
        with self.guard:
            connection = self._resident_connection
            self._resident_connection = None
            self._resident_lost = False
            if connection is not None:
                try:
                    with connection.cursor() as cursor:
                        cursor.execute('SELECT RELEASE_LOCK(%s)', (RESIDENT_LOCK,))
                    connection.commit()
                except Exception:
                    pass  # closing the original session also releases its lock
                finally:
                    connection.close()

    def close(self):
        self.db.close()  # also releases the resident session
