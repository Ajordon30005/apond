#!/usr/bin/env python3
"""Boundary checks only. No real mind interaction and no network listener.

The fake resident records boundary input and supplies a fixed response envelope;
this is not a model fallback and is never reachable from the service CLI.
"""
import json
from pathlib import Path
import tempfile
import time
import zipfile
import io

from fastapi.testclient import TestClient
import service


class MemoryView:
    def signature(self):
        return {'depth': 1}


class BoundaryFixture:
    def __init__(self, checkpoint):
        self.memory = MemoryView()
        self.calls = []
        self.checkpoint = checkpoint

    def integrity(self):
        return {'intact': True}

    def save(self):
        return None

    def interact(self, prompt):
        self.calls.append(prompt)
        return {'answer': prompt + ' received', 'verdict': 'TERMINATED'}

    def bytes_turn(self, payload):
        self.calls.append(payload)
        response = (payload + b' ' + service.pack_part(b'answer with  spaces\n', kind='text', name='reply.txt', mime='text/plain')
                    + b' ' + service.pack_part(bytes(range(256)) + b'  ', name='src/data.bin')
                    + b' ' + service.pack_part(b'print("hello")\n', name='src/main.py', mime='text/plain'))
        return response, 'TERMINATED'


def ready(client, job_id):
    while True:
        job = client.get('/api/jobs/' + job_id).json()
        if job['status'] in ('completed', 'failed'):
            assert job['status'] == 'completed', job
            return job
        time.sleep(0.01)


def main():
    binary = b'  \x00\xff\x1b' + bytes(range(256)) + service.PART_START + service.PART_END + b'  \n'
    for data in (b'', binary, b' ' * 19, b'\x1b\x1b', b'file bytes\nwith spaces'):
        framed = service.pack_part(data, name='nested/file.bin')
        meta, recovered, end = service.unpack_part(framed)
        assert recovered == data and end == len(framed)
        assert b' '.join(word for word in framed.split(b' ') if word) == framed
    malformed = service.PART_START + b' 3:bad 9:short'
    assert service.split_parts(malformed) == [(None, malformed)]
    instances = []
    def factory(path):
        mind = BoundaryFixture(path)
        instances.append(mind)
        return mind
    with tempfile.TemporaryDirectory() as directory:
        app = service.create_app(directory, password='transport-fixture-only', mind_factory=factory)
        with TestClient(app) as client:
            assert client.get('/api/chats').status_code == 401
            assert client.post('/api/login', json={'password': 'transport-fixture-only'}, headers={'origin': 'https://other.invalid'}).status_code == 403
            response = client.post('/api/login', json={'password': 'transport-fixture-only'})
            assert response.status_code == 200
            cookie = response.headers['set-cookie'].lower()
            assert 'httponly' in cookie and 'samesite=strict' in cookie
            headers = {'X-CSRF-Token': response.json()['csrf'],
                       'Origin': 'https://mindhvp-deltx2fw.manus.space',
                       'Sec-Fetch-Site': 'same-origin'}
            assert client.post('/api/chats', json={}).status_code == 403
            assert client.post('/api/chats', json={}, headers={'Origin': headers['Origin']}).status_code == 403
            assert client.post('/api/chats', json={}, headers={**headers, 'Origin': 'https://other.invalid'}).status_code == 403
            assert client.post('/api/chats', json={}, headers={**headers, 'Sec-Fetch-Site': 'cross-site'}).status_code == 403
            chat = client.post('/api/chats', json={}, headers=headers).json()
            chat_id = chat['id']
            plain = client.post('/api/turn', data={'chat_id': chat_id, 'prompt': 'hello there', 'client_id': 'plain-1'}, headers=headers).json()
            ready(client, plain['job_id'])
            reply = client.get('/api/chats/' + chat_id).json()['messages'][-1]
            assert reply['parts'][0]['text'] == 'hello there received'
            assert instances[0].calls == ['hello there']
            upload = client.post('/api/turn', data={'chat_id': chat_id, 'prompt': 'read this', 'client_id': 'binary-1'}, files=[('files', ('original.bin', binary, 'application/octet-stream'))], headers=headers)
            assert upload.status_code == 200, upload.text
            job_id = upload.json()['job_id']
            ready(client, job_id)
            payload = instances[0].calls[-1]
            meta, recovered, end = service.unpack_part(payload)
            assert recovered == binary and meta['role'] == 'user' and payload[end:] == b' read this'
            chat_data = client.get('/api/chats/' + chat_id).json()
            reply = chat_data['messages'][-1]
            generated = [part for part in reply['parts'] if part['kind'] == 'file']
            assert len(generated) == 2 and all(part['name'] != 'original.bin' for part in generated)
            downloaded = client.get(generated[0]['url'])
            assert downloaded.content == bytes(range(256)) + b'  '
            assert 'attachment' in downloaded.headers['content-disposition']
            complete = client.get(reply['raw_url']).content
            assert complete.startswith(payload) and b'<|hvp_part|>' in complete
            with zipfile.ZipFile(io.BytesIO(client.get(reply['project_url']).content)) as archive:
                assert set(archive.namelist()) == {'src/data.bin', 'src/main.py'}
                assert archive.read('src/data.bin') == bytes(range(256)) + b'  '
            retry = client.post('/api/turn', data={'chat_id': chat_id, 'prompt': 'read this', 'client_id': 'binary-1'}, headers=headers)
            assert retry.json()['job_id'] == job_id and len(instances[0].calls) == 2
            other_chat = client.post('/api/chats', json={}, headers=headers).json()
            assert client.post('/api/turn', data={'chat_id': other_chat['id'], 'prompt': 'other', 'client_id': 'binary-1'}, headers=headers).status_code == 409
            assert client.post('/api/logout', headers=headers).status_code == 200
            assert client.get(reply['raw_url']).status_code == 401
    print('Boundary checks passed: all byte values, whitespace/ESC/sentinels, authentication/CSRF, plain passthrough, native-framed uploads, strict output files, project ZIP, raw bytes and idempotence.')
    print('No real mind trained. No network listener started.')


if __name__ == '__main__':
    main()
