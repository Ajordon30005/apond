# Separate service branch scope

- [x] Complete copied repository and `mind-hvp-web-service` branch; original mind, engines, checkpoint and resident teaching session remain untouched.
- [x] Transport-only service calls the existing plain-text interaction and native byte organs; no new learning, selection, entropy, memory, generation cap or provider.
- [x] One resident serial mind, ordered durable turn queue, private session login, CSRF protection and idempotent submitted turns.
- [x] Multiple arbitrary-byte attachments, length-framed sentinels and reversible quoting for byte 32; no delimiter-only split of binary payloads.
- [x] Separate strict text/file/audio/video response parts, private downloads, complete raw response bytes and safe project ZIP delivery; no automatic execution or extraction.
- [ ] Embed complete mobile chat interface and verify transport wiring in process, never launch or publish a cloud listener.
- [ ] Include portable root imports, service requirements, local launch/HTTPS deployment instructions and complete single archive delivery.
