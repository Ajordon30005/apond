#!/usr/bin/env python3
"""Private web boundary for the existing MindHVP; no model or engine changes.

Run this complete file from the copied repository: python3 service.py
The HTML interface is embedded during packaging. No server starts on import.
Only this wrapper uses web libraries, SQLite, authentication and file framing.
Those are transport/UI concerns, never substrate arithmetic or mind memory.
"""
from __future__ import annotations

import argparse
import asyncio
import contextlib
import getpass
import hashlib
import hmac
import io
import json
import importlib
import mimetypes
import os
from pathlib import Path
import secrets
import shutil
import sqlite3
import sys
import threading
import time
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response

ROOT = Path(__file__).resolve().parent
PART_START = b'<|hvp_part|>'
PART_END = b'<|hvp_end|>'
ESC = 27
PROTOCOL = 'HVP-PART/1'
UI_HTML = __import__('zlib').decompress(__import__('base64').b64decode('eNrFfdt2G0eS4Lu/IgXPNoAxAAIgQYKkSK0s2W3NWLZWkt0zo+bxKaISRLUKKExVgRRbo3P6I+YL9mF/Yd/3U/pLNiLyfikAlDy7p90iqiovkZmRcc/Ix4/SYlbfrzlb1Mv88qvH+IflyermosVXLXzBk/TyK8YeL3mdsNkiKSteX7Q29bw/bZkPq2TJL1q3Gb9bF2XdYrNiVfMVFLzL0npxkfLbbMb79NBj2SqrsyTvV7Mk5xejHlP1+vOsvpgVt7wMmp4VeVFCjQVfcqv5PLtZ1EHhGkv1qYpV9uv5dH48HwalSz7nZcntohV86BdldpOtRPE6q3N++TJbpez//G/2qsxuk5pjeYC1SuqsWD0+EGWwdFXfi1+MnZVFUbOP9Juxfn+drHl5xiQs5/p9laX8OsEvAE3KJ9aXTTlPZhzrzOfpfGq+ZKv38HY8GafjU/N2ual5Cu+PT09Gx4l5f1NyvoL3h6PJ9dG1975PE4m9H7u959kKu06h5/TIvE4BRWgcp4dHh4dT/0P/+gbhvYaxWJCVSZptqjM2mq4/BCMXyHHGxidD83UOC9KfJ8ssvz9j/WS9znm/uq9qvuyxbwG09y+T2Rt6/h5K9ljrDb8pOPvlRavHqmRV9SteZnPVGiHEGbtNyg5NXld9uE5m72/KYrNK1Vdapq4DRnW/AryqMhjAqlhx8e0T/fuP7CO7Lj7AUP6arWDk10WZ4iQUH85liXeLLE356goKplm1zpN70Qp7lC0R85NVrYpeF+k9FFsmJWDfGRvq95u6Lla4e9YbGGrNP9RJyRMoiuCdwfsFDLZ2i8PX2aascNjrIgPsLs9Z/45fv8/qfp2s+wtYdlr6vpycuoRpW0PDq9rvOIn1XReb2aKfzHALnAHQq2y9yWlDhICIHqJwnsGsJNc5Ty2AUz5PNjkULNbJLKthxgZHE1UtMQ2KFSM07p4TbH1YSV4i6vaL+RwI1hk7XOu1OJsXs03Vv82qDHqEdopNLdB8vP7AqiLPUq9NWUA3dmQ1dlbxnNPwEQksRPo6PeZH6YkqOMhmVEShOWI5W3Cx7cTTPOcfYMHhf8mmLuA5y3OJbKyqy+I9gAiTg2vzDIeu3qqtMxocT/Q7BHiWrM8YgeO8/kuBiCXfS+iqsl+sckS8dVFlYjWTa5gMoCbnCuiRDTM9rJM0JZQHNFUY26cvSMXneXF3xgTqn7NZniE4MFmdYY/J/2B27xZZDdt6TURuVdyVyfpcbiEL/Qew+wE63ftweLs4tx9TfNabC+cyBoQariA6mjDLAYpldyhS116X+PeQfMgShsAIglDqmXPQDNekG8CO//bTrORybwG2b5Yr1aKe+GXyoTMGhOwxvrrtVMmc93FrAn0DVO3XxbrbJYJLBfFHvOB1AdtwCWW3F8v5vO7qYYXTS+QjU8QA8YGqsMG4YjypHKqpFqE/y4sKdr5ZFLsqDDzJZ53+CKhsbPq7ek2voe+0XxZ3NpEVc5kAjVv1Ac2WQL1nXNDBv2yqOpvf9yXXP2OEgv1rXt9xHIsEQswMUJChhfAStBNDCET3e3Z9gxtzRA1GiZgzIoDjvSEch84mFE8+GRjrFu4A8WR9wSUOgcYdjNgfeQGDA4reepstecV+4nfsdQHkGxkn8UyW8xpgpX1JiNYfDSbWcJGc9TVtl10fOVRNPOn5yFZERB+yIuqDRQ3szeYwK7XHlJAxUiS1Xy1KEpWGMeDPFojFHu0ub66TztFpj52CdHoy6bHB8MQsy4rf9UESrh++2GqFhsP/ZgZlyMHXs+t0PDsOxzJ2aC0+shExoQjpEeIiki2SWrK/AlUVhenFnVyc4+HwfAsHpZGcMUTzYNxmygSY21B4kVV1Ud73UY8A4C3BZnyKoxjiP+NgI5AQ641hGIzhBMfg4ylwQSxIoyAEmRclbN/NGiS6GZIgDzQUACQd68NCStZLJH8ERAAogMJn6KyalUWeW+JqvchWwWBz+AvN4p8+6QKKi1tCnc05veqIP2ZPCWR5IKLt2CViJ3lINowg2UjPuVyEQz23MQyxRxDdWKhfTNN5tMK7pMySvhRwLlrr5Ia3rgKhas6P06QBc0MEj82sJ4mNjh2php6MxHkStEFqnoU0hvlFBRmaK1OW5yAFgRJhoZjXPsrSt9zA54B3HN/0agK8JZ0g5vhSpdcdX65rW9+Yyl0ZWXYi33qiBscNe9bj7nNQgG1qASJJowgkWS4VGXv4iIAhyTCrCnsz7a+gdVtdgv9NfOhHjYy2EWO0bJKspWxv7d2g7YfOzM0KVAo9Jdv5mpmBQxy9338z7dybZNhSjILN3yQTZ5PYgsAyybCgRuf9xFgirLLxYUBmjQ5SctQmbw3VBtyQMqJV5eTEkTS+QOgTNNTltyQSH28XsUkMbxSbSfBHQRxaYWPBuZWNQEiXDRvCGbQQpT96U7c/Z7DU1oFturKZs9O0LMvv+bUQq7ez4+M4Oz6a7ODHUewNNnQMcEWL9xB1rO0bpdMRXaaJcsNaq0k6Gt/e+askjCHVQ6TDqb0D66TeVH2EytHGg50gC2oZ/GH7XWP3VPP5UCB1cHFvyXs43E2A1TJH18IdYIoG1C3cMMLzHJHh9Pg0PZ1EWh3ABiVbWzNDDevcJeVK7BWnk+T6ZHZ46ldYJyueN9hU/gq0ISWaCeoacTxSdFHcY98QCYL+S00S5fhhg3bGpxMkNKr47R3rk3aKurBe1vFwl36wa7m9VZVUC9WpJMUNMRQyImp5ygo9GsdnYDGObVJ7izssxamb5jZu35RZek7/9gGz4V1Nhn5gKQjjvJRCjiB4gfQ6drpt6K/2TYs++3ZKp65ooFUJxGRY7tX93YKX3CEao8nEl6JpneM9rK0OiH8MLfVBSlM2R9kmX+3UsRqkGaUAFnU2s6Ut7Jhm3MJQg8V9djQlLLbGPh0OG3XZUB/mh7PT61kMjbWfodugLTtDFaW7u2XaySRgqJZE4JBUYVqok7L25qePC2tLRA6NW5e873KcAFXc2Y5bWsaOQCaetAEW57SPS0O/htEW95LtiMzPymztjMcT1kLtGd8ITRkEq0Vym+FKoMSVoLK8XYde8qoCza8iLPPRxlGJDfkQvWqcOpxIKUsSQWUL4/msWHJPdIyq101Ca6OBqhEzrDGcTIYu1fPARjlJwD6ZhGB7ZsDJkb1o4imq4XhWzPE0YjAMpkjTa5Rw0GA4GE0+02Z4OAlI/TSQ0I4szUuNd1as710kOAoFi0lkD093SZRBVykHzMyN3ZlI6OGRbe+1VNI96GyMhBgfj9zwggrsR5LjAMM8P1zwize1P03IC1IW+ui09/fSZPjZetgu03hsag4dVnJkb3ZJRsyaumZ8t5SlAD1MZPfadtZKtZ3cJjUprNrB7VDuk4gMe7rFyiM89d2G3f5FUx8H3MeMqYMZ06j/YRI2tqkXRelJgeNQVZsM/aqDDRCXyHS6ZsVEmBW3yW2qBelgdz05h5Nw6bye5XwFXc8558dx8WXCj9BY6S0v2nFwS8l9ZWQhejeN4JCUKB4qSOxBKUOi6PT5TQCDTSKFsdSrR5E1brnTz9QH95eVVOe8LIvSh9KTOBtcDlpGfJCweRpVMUIJ+gvHhRoBt8mT40wjgnS8btrw+82843N1TMUOEO9S2H99oaFctMrNCrXh1lVva7F/3/ANT8mav81ZtKWFOTCpWAt61bR5aH0fMYns9j3SHFqyShR3JkKc3o9n7+ODiUDt09tDh95acSwDEDAz0OVrlDreR+xNgawheGs4yHF0f8Z7SZq048+a63gf+0/BHLCiP0vK1N/znsf08Hc2hghDQsxYqiE6m2dlVfdniyz3ofNK7x+yYJk1/AYu9axt22FUPFvNi8DW67ujqCQGSNqgXefF7H1EBttFxqgxrBCzIW+jRjRdE0eolDDs6jIt7lYoqhJKPYwUNApIKgTD0b0OjyIS3HRL8IEDWdRLGhP3osPyN4ojWo5Oohsl2aRZEVlUR7fWIRzjgFgcRVu9zVK+s1XU5UxwSGCg/HrEx5PxMD6ZjTBkq1tYxbSPsHjoNWpm8tqCNVQWNU2Kl+sC5L6+Cq70FtEZkHHi74jDUg4gciVN9grCam5MBmEFEGerFS9dlflkMo7ZHBTZRVdz5rh/h0I6He/vQm20FqrWcc1C+maUqGaZJeaY1TDbdlHpGWXjw/0jSfz29teA1YQbJUJaQoUAP3o4r/k6HaWT2WmA+aKmeOr61vcjqS0o4/tw4sbf2dE5bDCaVMEAZCTsXYYWuCCe5+vp+PR4ehzUGqRlcnMjfSBbIoCcrT0fzid8du7G2qZJteAPCLZFw/gNF1t9b3nnpFFRt8nRSKxwaMt0KN0iW3++ow1t9+r/p/v42/YyCshIdce/QLQpAPwyQHGHj42OdoUjYitaDXSFhwbZkWo0CBE2wFNh3f1Cv6zdqRQ2tkgup3vJHmN/NCVfFnZ4TrM550HhisdfbDgLgdwrAsse1N5y99frEohBvZPfW7bBySTYctOh/wq9m/S6x8bT9BaDq0sulksE0FkzqynJtlkOj3w4uHocV9Yttn4YEe6G3jScncEUzPiiyFOabkU/T49Pr09HIZ+uiyIXMSy/c8RKYHNRPK6uk9ki8CE1y7F760E7Q5j1oIHD1Fuk/6+nk+lsOvTMEA6nltOmomD2mTvFNvgqDUfvbNzDky/egM1RBGqM8/l8awSmTTotmM9WRd3RJ2S68W09Pj5KDtPokPc4euKvFgbteZF1RlLeT77yPauuw9tbIRxKWrpyotjx2uuAWIEDh29ORMU8+8BTO5wChUUSlBu8k7/zIisG7ISLHQ73CBfbS1tobunztAUxkdJkEmhnem8MHY+PrqJPOXgC1WQcL78YmZMHE3Ikjj/LjziYBl7Ew6DHlAtfdRaaQWJYehTB0pOJ28thw7jy5JrnOywj422BaHrmTuMd0Ek7f4UeqFTM0vhpglCXE5zRUWYijNKBstpcL7O6xwYlh02y4rM6oLDuMYcmereTbJJYGEDn2AMm0XjlRh1SjED5CnZHivxONn1NSSeezUHAowOl9QmJqSq3h8vZDQiaRvV3H9m3+8sEVNLd+/CzLsFybI2pWivjxZaofI3ieBBJI/nhjF9ze4oatNFImKBvE5SbOFlly0QwF4SLDaaTiuYOZLZsNcfj67zJuvff3/P7eZkgXaO6eEIW/zGBr2WB3o3O4fEw5ehQ+qRqLnmaJaxjaVYnx7BsXajuHpWLMEm/DcsCdDykNuSRPeuQXTMLPbI4qAzv8kIQp8e3dz12iDY833U0dM40WwOnnxiw9y+dPpKGrmuu0CXNYUEXqYnNjbfyVbUKVgB/seYre9RxgIbNVS3RJJgxn/zrGTyc2DJIgz749Xg4vh5PjodW3/Hw9mEYjz7eLWA0l9Hx6GN1MHS4S3zwfTZBVHpzARMQLQJhnDI747kPlZKoZJOpCbluCk4nphpEojv9+tHTgfxqB0hHh1/yOSinTWpVU7G9TfZOxJqJbcMVGx9Hi/lRtoeTWDEVWBWIQkFBHRbV4DeMg6EC1fzAs0MrgO/IMa4euXBaEYAmmpksqyfaNO0Xjgd1DCMFVXCmHxrhF2wM/nDP43iVfe+B5yDYvSO3l3JPaY/3E/mbLNbjiGljdBwfjtTeo7qZbQ6yqdZRQ1uWbulvWRu7pk5tHXociTJG3acb89sHMpxubg+V5tACoJG7Hk5OFYcW9EQpBlaZ45N4PoRmO2YDVbT7HRIR9ABbUyqbql/ydDPjaX9ZqKMj+Ixg/mOP/ePZ2TUHBsjpZzIXMqeWefrpppTCz2A4WlYhN892FhNwPT6QeXAeH4gsQo9xk4oEObc3jE57irm4aNXlhrfE2l60hi1JGugnNXLR0rxXn6DQUycaaYmEO4+r++V1kbMsvWhlfTwi2KL8Qt8WH6A5Uungv9bl43VSLxgUejk6Bkn719Eh/Rg+m8A/7BAkZjZhk9kJqpr4E/4ZjWWR8QmWGZ/iS/g9mfWhWB+L9alY68BtfnQ46x/1D+H/U1HuCDo4YlNq++UpENLF6AgrHQjgoyPhq403kvER/GeP5IhBQ8fwZzSWf6fwd0fD63xT7Wp4NGaT29HRywm1vAtUElJ3NLk8ZjAvY5xT+DvF/3YBikfPdwE6xpMkySFML9kI+vDrh9O8P2GHvx6b1+ywf7gYDe0X7PDfnFWbsuliCv/CeCc74Nqs95i+0emvk2UfB30s/t3RKLptdjYLaPTDcTJmYxrFsA+/YJXMC/gLyzW2X/THv57+2xJ+3h4vjnF8R2KYJzuHSXEDuzFwNLw9ggaPb3G3wFa7HU1xC5zcjoa0OvB5R0cUStDQEUbkM3h32GL3F62JJhmjQ0MzAD9ZCWWcbbjEbTiEDQoADQEh+oc7oFCBFnusLTQ5XkKTE0b/609wGo5vj2Dv3fZ3jVaKh3sg9sntZCHaPrntT8R66e/HgzGD/z+dElVBlMbJHhMtSNRLtJoNpmwymO4ACrWZHSswoRUYDc0SHFlLMIosAaLZELbhEZA+ASJABciCu+Podtd6oDjWANIsK2fAIGfwGmgvmwFcU+gfscTuHgj76LY/Tk7YiewfNtDwdryL7IC4vGMupjQXUzMVY2sqDmNTAdg4/fXwh6Pb0eHiaOdi3BSbnZQPkPsI28NtfUpkGnDyqI+TTf/uptmNSx6ZX/wLE3zqDmqMOJofMn9K4fftzeVX+CvNbqnHZA1Uc5YnVUW/mZsLqAXKMy9rCajUnLCaUsZ1XfMC0xjCM5VtCemChLGL1jMymtgiFTC8OrkmXf2i1R/BGA9ERdljguBQhxIu3Z9+djpwm7ZglyNWwKoMRS31NfIdgEHxSL4ibdHkAWpFxKbLx7A32AIIyUXrayny0PzDnD+mIyKyLZUMqHWJZaAAfINyAIAFjjXZcqzPBDu3AFK6rLNoD12BYJh7jE10pAfnLBqimTUUeyArfveMhAfZm0pk44H8ORCR9KQAQk+GmxPSAxA0dNm8lxendengEEjMY11pldx6tZqxj6kS1opuxB6XX36EPy0fCsxUg5tgk1v11na17zBNSFCPkoe0Lv+12JTu6gIlzHMGGxttpmj9Hjw+WJt1giHF9oebMqTlwCKL6JwfrcufVxz1zZT9/W//k3Ho+57VmxJWvGL8w5qXGV/NuNWt3YyX3qN1+ZStvMXDdhJ6Wy/woPjg8XV5+XbBKSIhRVsAdQ56330FRTjDpKEDtz8LBxUV1wBQno3fAQNlwwoH30DDGBuxZXM8PiD6RgQZU6FiAg81vfC7RfDSL4O4MAGgJ8pSwq7XQMQsq6BVIkpZ3hY3N3mUtESJCdpgyiIPqDCsNtBHnuIpgRwJkb07fkYj7pdTHlK/mgiPPwWx5BrIq9V3abNsXapEskCZ35MfCdHn8WJEk4QU6i2q/q1ou2QVaEVozmIUEHXvMVwtaaJtNY3ISkrhlPGWlUp5q+oYWqPrGl8/a7WphVd4Gr4lOZrp7XlR+12lBREzwd684j8iVvgVCFWIBKMfExZL88ZwnVFwkvk+TasCNq/VtXhpI+NrRTpEkZa0BbntE58IKY3NE8wS5ZeP0/pStQsLXcOLlEAT5lv1CTClqNlswWfvObSVplTxT4B4kUr4Ol7hxarmN2VW30dq6W/xqkiZYNQlZylf14tIA8/xfevy73/7T13pVVnUxazII6XVJ6vCQZoHU7S+fEOTjfRcgsRg8WBKyvse/pIaWI+hGfBuAeSiLhMqhtuSob+vWvBqwBwWzdKCAR/CNeI10X9cJJf+i70n0cXZWu6GdHeR1ggjEpfrTNgmcr0WJV2WhiMsfRwkQqIrfBZ1VCA3E0hXNjsQ/ERyIEstEGZeI6jJR7lNvGJv+YfaK0rmfVBNChxRkoMc3pLE0J7hNKuWWVX95Ha2i/3IiX0uKjPpGfg95Vh3ktRgTRIGDar9Soy15DdZIHXbS6+8KrbmM7RZuE3VpCtH96eeHZT1tRTb//NQPeUrl/g9Zf++yWBbUVwletAxQP39wCeBhqPavq3W5bclRiwk0AivcEywtaGFYgMKOez4klVQFFu8waaB++QFCKgM5UlXtpslJUiRQrozIiUr5pa46e94m2u6jjTJuz5PxgPlXM0VSdvrUHIw/O5zuiCDo+riewyw78mjQn9IlutzccCnQWcMSZxGXhRifhQhJBqb7AwCZm/bmqoMB4mDLWBAuQ5X0KZvf//b/4qJOiTOavRXkq5+oQBwKRQ9qCcZmqPFMMvJ1yAFu4dyvI1j7TR1/MQYQ/QLeys/FUkhcbVdaujVQu/X51IkC8WM1KQafmvRVcU4BIAAF3pn8qw2iyNJ7prkC8r8kq1gLyK3JU2Jl7BmPdxF0Muc3RcbJiJbYFdWDDN/0raK806KESHCCNvve3ho+ZPuzt0bDls5oc3qy64KO8S5EsJ6W4rTZ028BukLE1HVoBjUDUgkOxEuQdWqyLPeYjAKmDbym7YuX8psFUTpArmPGvAa1Sn4EXzZDCzPXYWWRmbFo1+0/gQiGfco4LWkkDg62DVyfCKA8pqn1/dmMn/gOaLUgeoxMoU+zstI7VYortqKh4nmbjncWcxrVPxxAtm3MemnVJDJxZMSjvPyi409hmvblMvxmLcun67uqb8B+444xvV9jagdo6IRdYqj81IhjgnoVgMXIZgRZFeiiRq4+1IFkn/ODGzWW5XgiGQLr0QsK44Ip+IFPqkhCDfXcpPX2TrnEXXo8QFud4/pE2Ox0TOYfRVj0Lr8DgMTcWPhBOLlLW8W2RwTW4gP0Lq08mCAH37/VyRGsKCUswAk5gJ2ZCksS3cLPGOqZH3Bez2Lj8tEBN9QVhc0qQhzuGIuDiugmISfRYS7xSutuHdFgNMsgfdyuZZFmuTKg25QIRe7mOpLK0K4x+nrcxM2rXzo1j41kRKtRpP2/0+TtbKWWAMF8ZFEIhTU7lFYKu5QTFuMdJ21qWKP3h1zas8LmdWyFSLSvS1/OaSaTIQRYyiQTXaXZGhZCI2higdRp6GoZMXgevz3wSLTM9R+EQYaQQX0ICIzGfZKfQv+6u9LydOI90DvuErSsCLYmnzXIv4v1kK9C9iZRR50PXkzk3kW1MI8Y1Aqbvac13g5lMgZ3jffSw4KRIlMOo7z32Hsd6vRUput3kja6qyDIrgO+ZUUxhLEfcOrTcFs1BNAuF1w8c5WYI1ssY45N3T8vW7Jj8j3GaVsj9CByaJkHbgBAhWAv3YBVLb5/azvsB9i7gmGUqMUB6ECyoOgiffIoJIh8QBBBuYUyypZ8CuHvDqSoZzTZLUqNtApSmStQN7aQ3SlTh6vCrHtL+U1Xl/bG/OjioDDALhPKsIJAPCjlESAsIoHHo2G5zKujM5bUXgi/RIJXumnCFtXN2pZgcLqIi0VukdBem7gHoa3tS7/KblN3oh0jTCreg8Azdpo2drXG6WgrUct2JL8jXPexrpVXWazun0uNKKDA/ZWivEYlAfktcIduYCJz2aJ0LhnkWXvad4pjG1/Ka6rgWrxp0LTiJ62VpCwagnaREoBuypokKcxXPlK3PS1qmr2D+wCEINdXLK0mG2w/uCG19/lhCHf3r9IO1kq77IRFTYZ1FCR8sl6fcb+odOGv+1uj+kL2uCV/I2vkafTO/xhlRNGcLu0eANFZPuWP46KWc/Yju13s7/TCyyg3QP0VT+ZDoyRiEqYR6wtTRP0Rf6m4ch5F0OSD6o3uQd0f/LZ9ChscPRd/MSaxlZnfcBH/CgP0OIH8ZOmkGN0PM4c/DCtW0qa+GqesZaWLemjfqJPFO6PcyA1RtOo0m/FUssHrGMrvs5HBbpl+VfgqGfTvC3TUSn7Bbaimaz5KgHUu0HMjnwwTTuM1ylDb3TjloBj+rBeesDai2y/0O0R1zKf6VF/FGzTfBXP7a6IorX3mshoZm03Qz/w+kLyBMHux9dnbLXJc8DBqpyfsXa7x/i6mGHmASIz6CXK8XgFSvFPgS7Wz/TLjh4cIizgzbsrxC+8sY2nL1LdMt5qY/3GMf+KVAbnbOgioGhjs87VRElQZ6Ab18EL/grQOqu4bF22hIRPwPsyWXdwrQFaPA1ZKijwxYvV9/JaRtmiQDG3qbRM5rXbmCQ4aCHTVaWF3oYP03iQxwWGGK7PsrhGZeeC3QG5Lu4Gy6SeLV5inHGnHZ4vajt0VFxhIt0uFxJspMPq18UFa4uccG32H//hvJYZ5dphe/8EkwatdbrY0rvBgEKu+YCYyG2Sb3jV6V5hvguQTzrwFovZkOA7GabddcDFFX+FQUyKXbQPknV2QBhz0AZVEUSZIuW/vH7xDPXLFaCpzznQ9/8dIiW0wcVfMVo+cBCb/eEP6vvFhSxAz5KzzkGAIY65gg47gG89Icj8BO2LexfNUS7RMxfsDPrVTE4gnuRz2Ii+sC2bs45ur6vqDvQraEX/tuvQoYlHADFerDgHRTk1lfHbM3k64oK9qdGyRBV0ryUnyVBWsK+A08NFnbGzokHawLTb/nBRz2wa6k9vgEvW9frs4ODu7m5wdzgoypuD8XA4RMUSyEYb/2iw4GFQ8fppDSCDzMuBqWHXWA7BwYU3k8WesDbDV+YNkqLultYsRQzbRFXMdC4Fjop/wWigtmkQHrz+Ub3GYqBgI+A4uw60GJ2zSjtQ0V8p+BpdJVzVX3GndWi/mbVBHKFXhNZInnBbmzcW2sgu2m2vT1RRQF83ddoVoVIbZl68PGP/9ObnnwbidTa/l0BEISU1SlpVO5hIsodUL0eh2scoecoJlgGK4f6k8gP5+skTej8Qh4XVk5SMnH31tCyT+0FW0d+OqN7V4xXPQEXXHbqECsiDmU18M1hWN9g+/u52B3hHZ6f951XbXxtTS3aBM63GFp2LalHcCVdnR8HtLNyjCJ1ScGvsygZGcPO2vGw0KDoQuA8liOFEYVM6mwUZyVqWKtfuNvQXG+ePWiQJxwqAGYll5xisonocj5xinwTJTqr71cwa0TrrYEQsyC5rYf0BGeeTj3QfGSqGuP9E/5IlA1NDrY1DiU/wVrbg0gzhOsdmkeX/IJ46stpAfQWkgF5VTfkWCUSn/XQ2A66PlAEvVJYK28FfqmLlkyf0khYp8lzVvHwDrbf/+N1bXJriF7zI51lS8Y6zHWRJZBpUFHeW/e6H754+p5cC+1C267pw/kv/2ZvX3/ffFu+JgFrlVD85p/gLYMmVXroab/TTdh31FcaQoAWOzTmIMXKBPlpWZTPzPQlmT0FDkhyuUwaLBETfuhy8jbewzBYg3YFe00f9jLd7VqsY5ZfkZ85iP2FqMsVXoGsd740UifjASLfyU1c3bhb3E8AAg2IdolFda1i4DvRyQDm4iKqSgCyFdoxsLO4EsTzXtcTaY8JdjNURaCa2VPtZsclTGfaCrpTaWAEGTNiT7qX5UxuVQM/HNTEC6MCgGVPdDFa8pmibC4Z80nwXEMpSesQOlpbJnV5etd60vTsOohB5F8zJwRX1AZt5IljMGm+578CLLhPCtjk5KKf6N3+adcfFezWt1rzZ1hJBWNE0uQK+iJGl6I0xkJvZ+WQTaaeDj95iCe5kL1WEAbZfS9IicimzDkoFulkpg3/DYFNbYg0TbavPF36F8/gsWBL90XCE25xOCdDOJ+GayGs78kGapdtdZ3tKWxaR9077Xy37NcNtlQ6YMtCTERNNXsrr7KDbJw+xHNT/5HJanLUo00JSKeeyg0caDaiy5kdJQoAsvPr5zdu2JiVn8KktuU7/LUg87bMIFWafenQLfCDwiM4+Oezn4IA9dUxvIm6ZEhKgrV+6joRtNSEzGaz9LM84nY1NuUXdBu44S5zakub8JaojPhNT9gb8yJQ2Qxo7LbzF9YmjOuYJi6nazUSKP6CkvkR+j7LaOnrBYkVpz9kfuk5tKaZaYqwSGYTFwxMv/KlBGocaxTOJowxTcIL6vtpUbY2hZ+4EQ3HP09BGFSRuxQ/Asgw+e8CmYYBO1cYiEIm6E5ygWs9ARqtxq1GijAbzMtvHH7Z70Mhp1Bdy2oru8MQxUs/fod+2DP9VQRiKXiMpMZytoqQ3KyWayW50t/I4gARn0I7SD8q6KkiZ2VKd6PaBCbDQDqB00aw7oLY6cSXIIZrqQhRXqY6ZKLyda+QuB98t2wX75oKNvOJGcElQ4DCseJbzpERTV7Gp5Zi18avrNqLfe2zbsvtQax2vHhluoM67K/e9sftFG6QrvWMfhN0v0qCwvcWB0AwzbE/bDhumWhoSt3xVVsVo80bS8lsAzUp+BCZvEUu/kDwvtb2QOHeypYyZVcuc6uAKojZZ/eP0VNvw45+VewIGTPFOzzDTPvAssxJQyPKq7FOOvCtRxdXtUpewpVUoYLlFGstId0tzL776HOmDXD0eIW/7R0EsEwsychG21um6b59Kt4b/XtpMDVbz+o2wK3ekskp/7DkEQWZAZx9DmG23R/PAbX9D4/C1j2RHO5IRN2Hndm4eiD7OFpLcFnA/CmSDIUJ9tsm/Tbc9QwJlVNPxEx2hINt2G2kxI8r8yDaYgfr4SBTfqoikmVDlYAticC8Ih6hvA78DfdsSmn2CLtWMwNGyH2PwWY0zbzanwT+uNULazV2r+T6L2Yh/HmbZ+OtSMoP7j4RfRLhD0D/t7YI1aA38mQxD63j2FGJMb5MK1VxkAUhkK7+QPERlSvk7UWi6kgMMkjx/w2ugBmnnnW6/Z7Vy5ZhlHmlPRYdmsOtb+rCQxUYHOV/d1Iuu7FWwUITbLvRueDXI0ghFkNQ9IqR4yE4S1huh0XVCk11AE6I73iUK9uJ+xq5tmx3gmpTkKkntUxke0OznKrA918h3JoT+T11XY36kGoJNKze0fONtFdrh10UBssaq/QATg7weQwMcsTMwVwfQALg6wbllVGsgjhJ7ZE9o24sORbWokMqjdKqSY+pjjKM47Ii0e1jAQDt+hSe0ylukb+9Xxd1KOKrZEtULNE6953wN3zbEJihUAOOSlD2KWpRBKoEhQphGfPrejG6+iG/LbnaiKQehkzT97hamCEUYDtSp0xaBZ4BgYhNhFH2NDgU1bHoBe4/+PufzZJPXrnG2gUc20wIXFewZbt42TLmO80JYJgZAokF9wn0CrQkT0BNhSL1ocLP6LYjStnnKhfjTFshxttG/IJDOpTjnqh3X6BbwFX+GXEMILHFQY28WFbNixESfUK7ZUsqTEFGXR70gw7DP9udRPthOgE8RwidMekj2BoOBbSP7aCboU7e3gyjCjgWA5xlsQ9TCZ0XxPuP9a3EgU5EW3LfoO81AzyN9Bs2alvTyX0SsLcq2lVZfuLT6YdTV5wrN7EBsxYATvJEmCiXfwdwApmTVAs1/sjFprL9bcIpuF7MsDCR8RXjl8IeddBoB7UjMgNkRvwQF34NKewgYJ6uf8CQuSDs2Rm7fVHvrAjtZ2qO4CNmNyPKakstnjxeE1HyWZ7P36EiyCJKpq7Xs5oqCC4iwmI/b9XMb09y9HdnMWLsX2LKdTfFQdmzIsudttnzUlpOpkrkszijyYidabLdKWOvylSE0JkZViLaKuqhAZdwRtvcO9nxwQmsQk2gt+d6P2GnWYx5Eb0n0bgfy5A753riTsFVUFd3ABbV1sfHuvnKmEjJjQb8RQVMZ6Oy+VOCWsMJdkq6EpAT/gnLhRh/5H4i1R3sZVGh97CQ9dk0bpPOcLIvk4LseCHUt/S2pKYxi2GV9p0QSluj6ROMHMcy90d9bH4oIMz7aR4GPNr41EL3UDG/dHnHDsAO4h5/zMrmJh5Q9l4/fyxIdy6ZRso5RcnGbWIsQOixzjLSmGLd2ntkIIj7L4w2qiHjEiAWVeAijZOxqosQAuTKyAFnBxXkZmibxpmtF4BnDcFe1FAnlkqdMEAw8oRrpXkZUUTAbRUiL+GccAh7AsQdAJ/PaItp0IBK8YlDFLyv67e4kxx0rA8cEWkpbDGKsGJeFruHkUC8XrLNfnxj+9tNmec1LoA0/JT91ZNsYQ49W+Q5QhyfAbdF18ufVLxIgxERVsC5+BLk953Liux6pMlGdne4Aj+SroE2M00QYXwhJylu3rusZlkFcRa2xxZ9q0Y+9XAzLx5aYjiZhXeu8tVvRXWloJupcVqUaebbg1pY1RY/ONJdnqhvRnB01ITegKpBnQdDADtu3amG3DTw0BrFLNow6nMgf8s+cSIqOJfRdL4hyv/0GaPvbb+0whiu55c+xlY7vo5K+FowMMt2geKKOEHjOhJ4J19ahwuLNlRZhArJI3nG/f4lh+FZPh4TmxoGm2+zXELWfiL/yIwWQNniaVHmEXdRRsJ9ZXqgmuz6mvH5FfWw1ulnoh9Y7OoEv7ZzMV/SN5Ga8VyZMSXqsfJlesa1XOV7nwEQAlvLdinbQvXrN0ZnM10g/RGpqVt1lwEL9/A7VwBd3HJgxwsyxznYDr8VOw4GFgFuch5Ik6SDwLS5EF6k8U+9muUxA5HM3GUg4qRaD9mJaeziHVFdPYBnFzz04gHCKN/mTAsGnyaEU83l5NovPc6w5StwXoYOQrcnaLqeVtgXtgS07KKgAyDvj39JJPwVfNNjWpYf7ROAKjMHzCcH67+0mEQVupSf2gn3zTdRHu00bkRhudBF1eKLjMq+oLmIohjV+lHgzmgYF2KOLi7jzuEGXIZhCTYb2jEKs7meYzO3d0KDFoKMK/jgWh6YtuJfYZfF4I1Kr2A309jmDciQhEXUrLq8AEeq3jNSkjnMERn2Xx2AQEPeVsF2hUEFnvtwecIvfoCxTgtTm9dVjmTm3OYid6EFpUf8+0weAHPHqU0SYEmRFxjJW9hYLdLGQ9jQSK1hFoAnpJuevijz/Eu0t5A8Co+GT3mpNGL1T+7Onf5/4Ao/OYHl/DaPk1rOH7QqxEJL22hazKRcsvniL3N2xBMy02gqsHoPFMGDzF5AIVJI6DLlCYwuGrrnRpzYiOEJFk+/lU0Tx9Z2NpMwSvY4JOE6ETdeVY51ve9PdIK7H801G420innEv9KcTs/w1EmrbaNRzYlg/furutiIZ6vn855fffUBxDT0nbWmxxP5WIIaS8mQhcAOpVsYb53CQ/0E4bPaKYZCLlLh49+L5FuMTecvpyIUrfJEVSp3RUYIeHtBB8etRRB+98nuIiYqqdAMTIZ+JAMgcwd7GzoCYOi9IL1ChwQ9jRI1hQ1top0eTLTlpFzGOKoWa+HY7ru9JL6yIPojsQb3hQ+9AjGC7xHB7wN1+QXd7x8zFaZNT9WFG/v/XOlmdlLVIG+bnyna2WVyx2lM4Ra91VmyqF9sE3YiSFvNm2HT+86zk3ux2G7S5nVF7UjjbXzltiJ2hsakjc8HGHbAwPTku6krSZvtoyYOknNimcYicWbXzOLe2LNdiVTxSHTFh41EUTAoiMm8lFRNhD7XnmrR1Ny+eKthwluvnj7i9yGKpbnaDmVphHhsQ/4EDwIjwI3T7w9uXP/bYy6R8j1fCUEIS/oHPNiLwHCMWBr4Na84xK8UvZR47J+scdA3i9pwog/Cwkm8GLnNpAv7l9Y8daffyYybwHLCH/1BPhlIQBPEoC4LnnTiDTIIe/KjO2leDbDXLNymQfWxmLbMwky6BL/CiFhJm5bNy0EYHpTkClkRAAwT9zbIl2kexgpj6EvbVm+yvvIM59qrg3Dh8gakSBm1ZxImL06bu7+l+1w5WEAor1nyMvqHg6DLtFfF5NBwfGVkR3yH6ftv2znuvMiF7tP/5W5zSl/TvH+nft9+2r+zzasp0SI0dUAf2Z0osBJ+H6qVITiePYV9eUAVUL0TBx6JvZcHtsxHOqyh8IAqfy6IUtOkfhqKSvkVfS249cTtdttwsvy9FLvnngEKYl2IE247mgjwDCMM76uYqfjQCxvAK2ExnDf/4a0jX9Skrf5rd4qxhBcpO559dRaExVhbe+0XfI6HEY0BlPcDf7ldxdNI6d03l6DQ9RT2I2riPKV0uqblPKXGuyVuE+q4pR6l0qdyv+Msr10baYb/zoM1W8yI6MvwQJBggAmFTJIIeXnfDUX6nU0lQ41gXYEwIKOVUoZ6wMDw4GQUkWUGsstqiPY1hUSVsXPu9ul4LO8NkEybuCkah3BpWhfBkciLPbb6ztj4NjnZuz1+wZQbA6vQg34rgHHXOHvM+tv3jy9RB1wXIcTDRXGBv7Z4GyGhSgGiOQzCGJ/JXHDnkrzPRUZsip+ZFZMK/8n1hZmoJ3gSBVW/xvnDHp6U+2EsVfvTXKyyxzZ32XNUOElFYDSj/pCkt+FCSU9rUqh2p43hc1VvHgGAtg/oe+MqQfqhCUN6fYjKjBcsHe99ftW64GOJmTrkSWN4Cjb6pyPoqEBnFZxBE5Ly3Medc2/9elTN/0eSH5vXwVgCHGQxFdZ8n99ULuh69AUA9uU6oAOaJ+Imwjw7IqSxtM5ReKa/7vdA4RBtkDMK4Go1miKWuJcheJKoVPydNW8Iua5mqpGGXcjrjM0iXMjjaHOk3IOA52tsky1VcsACYsvlagEn+iD3GfaIiYaC0vyq7q3dguPNRpJvFKKv/IcyiPSZtpfDqtfiFVIoS4aO0iKmvRP7LlNw08ne7J493IyOhH/BGmnMxhEsadnvAivXg4L3M1WS9xECvdwLcKwpO1+RUjuG8ObIkZqsN3SFSMFugZvB9kefEsO0ayF1BETKJ6wbwBwr+QFfrgQwT+/i2WAdfxGlnWQ1ktdHQYydFnr6h2iKCN9aoz3+k2cW26yKdcG025ptjuYm8dvy6v0scjuU0iPkLlJREJFeZ7fHRDzVBpX9GpSQ3Ec+4f2Q1ypQkWkICggoAMTAmfrl5kuw0JsLm4kgy6r5t+TkMDQIErck/7fJiVU98dmJX6Y3DKSKwalBRa46Ai745SrEQqQsUDquaLxjnXuFVyPT5JbbofK/uK4xfotPV8ucZUqPaJu9yBhTgYhi9pmETeGgnoh8h/OpKG7PWxkVknafFgAYp3Lvlwhb1AVfV9BP1S3l/zjx30HkQBwqFAheV5ZqyvUiCqgXp4pSnyn9vU7JoxNB1kt7wRjSiKYEXUertBgRhOwMU/YDhmlO//ohj7rmuVxne2iZjr7Ddlocb1Ew0EEluVlVQ1gvj7Yr0vmkn4rdwG860NTlaSX4O6yEbcc9mO0QLRXWkWF42LTUV+JkoqPOCaGc3dIY+otbMwSp6JItLcf0XCsfWSULsyT04YHTqmPHZopBB8Si03GiTEc7qHJC2UldYrCpxgFIGtHpw0MZ/ZEgGJT0BlcQjJXFosAGtmYrSNWUg9bx6ZnpDZdXJxietSbgOg/WmWnQiX+XyRUQotcAEg8xI6LrrxEEtBPtdWwlaQmTuKeHSMiHpoXW7fq+uLSCK3sKnJKvN0DmJMqe2csBEx0hLQA52jBV1u3YvmrwSKPifZEIJISH6oeGMvKEqM7aoNiBy/1ZKcu6lKNqGK9JW2ddo0tVkGRkqlejnSshW/CHsWTUgOT5P3lcbCLpMs1kdhlfHClBiv4ZvmFXC7jZKFuRMtn8VFYXV1yCr1243ZDoq0ZEqKZ5RUFRcCM/mSDYkbNvnYTqsPSClcm3biiBq+p5Sb2/HOA2qMpVPKBUJIXW8cg3aFj18J226pLmJHMeovF0hjXznbNl3WoZL7n4DJQjzPSV3UnOGB33u8zpbta968brrskDCKOtrPVy+pshn8XPw12zdvrIauYrTo9D+ZCdtdI/YkOIWoYD2PFo2Da8NUhhjJgz90TJhqHmMlGqwKPRYk4JLS9ONQFOZ6NzV+8aQBhy7KB3QLxdNqVAjFYwKn7gXiM5TdLWyecVwFO9Ni4Tb42t5iYA73/ihOdpefnfD4eFNGA6P/3+GfSv09II/RDsP8orGvCUWmoFcmN0kdVGiVri+LhL0TAQxBs/UN/KCVpXwo2mRcsBE1B8RbuK5lHAMxpHVAx8zlYcq0vPgDu9mQlTqiIVSaT//vGp3w2a05++14g/QZxY4xPTE5UlVU8iOfw70GVVr+5UqEdmPmXnknIqoSmwrq2R+JAxN3Nm6taDnmM4M09Z6MGoPj0zuh5Zjy2OoEgPqCB9n13xyZXCH3a3v9xGFKZdac0S9LB0Lq28MiorF1H9WQhjdgx9v3xC85ZdHOjB0nFSWkaXbaDaJ2z6E2US1RsJdcwPakOLnqMMgO4Y3cchD+EIuEzdAsKcsL1B4RSlJiz7aH4t3vfRLDkoRT4MMdSYckULY6dSIEdVMkKFndXrP76Nh3FLK+ACtCuOEpxtDPcc6rEuiGqsenOhHbaUjFTVaRKq2QRCC1Xcl+paHq1UrGHN5xui9GPmZHW70ItW3FDSfeHADdbxZ+ovIuG4f1PEC2GUQABQiMN3k6945nsawdWmKkkbOC91qpLlYXGlXor3bnFj4/VtTiBJtDLH+DjPGqYFqN6puPVaNRANX243E7HRlOaGNtcVZZUIqRAY8qO+gnBy2W0tNHjpay4i12GlBDNVtQE4X1vfjcgnP1QS4tcy8YEW5pzE7njxVbh3daDuZoiTGGRImW40RMGsuTUHptzvw3HZW20GmapTShbDGthWThbZlw/J2kTjvBvvjW7TD2Ad+LUle2JtAbLcpOEx1eS9EiaJ8mued9js0BvUBx/pZehVzKBH6+mQpYkfy9BR4hwy2wVplNsO5LOLOiGsGs+5ROI/GtJlQGCfEOhK4ZlL86cA1++aLpsMR+F7L4xKHsKhzpFAJ0TGiaqcWtKQefI21HYElGkOsSgbn1JqSFrpj/owBxg+EbCHRJO5a1Kp5JjQ0rmiyM2QP41A0f/PDHcVHlZb0RVVRNItTJBa0Z+W16hDwmDJfTL6k3LZYH4r5Ow7NY5NNd3ogXruW7gfEC8ZO1r9TXKVnuFXPFgl6mvlbJjFpRNTGqkA5eSHPp+B8iFKBAiC1OnFiOaQXcqQR6GWV+PjkRycZtAE1XlZZbGRRL9e47tex0/kz8DFQbgzO+YcfrFTUpg1XznICE58KsVM7TdGXZYw+NtTkkmjjrTqUd8aJNEdCL+5jqAaB5uYoLo2Bl1tPTW3N4t6Eim7mbkrFfRSbzIejijxtp3AlwAvH/RJomdbs27H8Myu5wYxCRG01YaAPiwSTD7o3pViZqdtZ6V52Bn3QCVKMHcV1jEePaot1SKt81LIOJ3UfHlAcSAlfdHhJ6OVyG7iLaswEb8ikTKfYMTw+qxZ48Oa1yQ8rMiw1xHFvyzRoRdv2wlOQ3auu78KIHZyKs2vrKKaX+NC3efkrhq7MrZHL28S+bwBrUWR+ZjJpUyBwucEY+HORnoei35382laMceQEQpTFeocCGo6hefqzDNAApTjleXZNjijoCncLZawRwAJfOGeaz2FpXGHRMULRmKlGTfV/UaoaQRg+I1eNl0tZdOBvDx9PfucELJHY91hu52Z4fKL3WnmIKr2objROYzYXtl3cdrv3A21s17TvkpdWETTNfLup7j2JMmKH0guepYZtCHe+FEnMt4uYWAn4Cl3EKiIm35SwR2PvBqpetNFrAbsZB7BOafbuBP1gYTuvr3gtL0/0FKBHsvaTeKjUGXukh/uEIjn01NBHCfQTla5fDwe/EtAyToRotTogSy/WmL5yVbcDQJ8XeGLIuS1NfOin8IVCchRIFAWuIMCrW1Lq2IwJeGSpz+W27UkRQo3C2G3zgoMmIslFtIs1H6/kGGSUS2xMop8/Ub4Vrw+zmk90YhYkbzSzjf2rWcWK1PFrGnbQ5Qu9FPuPzUzmC/qlBzYTmQst07ruh25aDPoIkJKu+anx4p0nQcid+ThIsTUhkP79b/9J/ePfoNdX8nRGU8eRTpwDHZHW9bE1mWJYXmu7M9mNldPXuirVut0j+iFAe91fJL6Vf1gneBsM9CntoPFGlfSmrKJa024eQ5BklRiYyLRaJyVIygNKPlHVnbbssX9XJmvXhNM0dlfSfOhY2yRRtLclIFRJ/z/3gKF1p8CD8lXsPBTtXFYQpGyO3FXg+U62nbrbYV7YV5jtORLSlZ8TNJQ4fZHOksh19kx1H5bQR7YKkY29NN32sOOehy2n4ugyZQp4QvqMp982q7rY4HAYJiN+jkcu6HyKuHC1R7fCFJuaQqyYsLCje8MzkG6y1DP/zcr7dV0MSsDhYvnLLy+e68NTwRff6UAhDXiMWRSErfeayv4q7oCl03BAoacidGx0bHQ1qvnu+ArPzuvff2CjCdA6dnzkFptaxaZY7PgQi43GU/8+PjyGhYmaqOwVGazwJ+4k/DuoC0mNAJbBmlCprDtj2LjDtr7qMbjo8R00PKhylBiHPTbFK8H1i2kP4HDejKA5aN55dYxmTOcVPF7J/vrtuDGb8kwRHlAAVvXwuyItoze2gDZv2ZKd5Eo4ED6SB0vghwhvsVy78fRWejNRo0o0Jf+DdY4KxB/nO8qLI52vrmqLM2lADi2DQJM0Td3/vkkSKb+ATpIoZqQbyeGQreMH3uBDGFspDVBBUCuWFgF7QRV5uC1SXp7xoswHdOZBnels/7LCnykTp5JMi/hWH+Jx61knd6SRzDrh1Yt1L49VWWe7TIt0wCuMDSv5srjlsSgWbFB8dc+p45vmKBb5fdu5pteiS0K3yExtnJkKu3YDZFB8iJbaU7CKpJFzNpz0f9Img2oEqsyfqvJbRHVZZ/ftOJxux2XgtLtDVOfYJBL05Ai3hGFgG7EYDDEkIlN7hWHY5b3MhnJ2Yp7H+G0eUe+fKaTXA/jpzzlMoXSoHii/LJlm0oJsN5I5I7tNNd8UEMMbm3dHEj2I/PRWosEBoOmyYyclCsfmzAr2sQW//T5R+3W900RN30AzKgalHbSvKMLuxtDVHbRn3weF1yFEwEVVz4j8vne9MdejlSTRVk7khFb1PeyPBZdGuzZGobTPdxWzPthHlYDXrD+090ErvPyY2NgeGpVzRRZ90jkonU+RdighREBBLN6P8ozTCHHTq+7+13NF734x4MnPIWwZNonH36wV2qPae36P0ZpNqprQ1CjsBw18dKkgBUhKHQ4kaMriab3CiDdcIhneo1t4hjeHINUcj09tnr392g2TSN7Z2V2N2PIOYLEnmrLJb9FUUyB7eNln0wzgisppQP//WwzgmgN1esLCl8QU5bkKyzNJR9MrVGm3jXUvWIv1DqXagZGcqRj41ABpFEZXKt2+Ojqr6w3Zaey8Cmp9yNImc+ki1xIzfhNE18Tz27s7KzIOZ39Z+2QevwMG+6b7GBqn8Xdd7y+ZS+/GP28yYWjhTO43/pwnt1Ei5i3ly6RegFb2AfUo/ysmwjgPFRxdoPuA9deadDPYX351T1O0yAPlg0cRAaH7YBuO9CysknW1KEQes8Z0zITgkWzMPXkZ8QutCJo0ZhRDIiMIG7NBYSGEGsQCzEHYdBGlfevmA4xIIMVJKZ8O6SgvsszQLFNjJepWWSwjr44aMMzPRNyMjpKb9iq+TtB/J9o4FxeBz3hZ483Vkg3gSXkZ/3rNMTqYvOEgg4A6lM1wncr7wR7XaO53g2nK0Y8cS2W9f4rpZje2a4drTLSoF7o52Zt7GZjOKIh5+73aX5T7S6r4eBWYyK6kbF92W2KHCzWlLeYfRWa5F+SKNJVHaH/L0rYK3G0sR1tDlNRNq/3SjR6h1KYFVVwaX5x26Z2t3vuavtW2v7dcYzXg83cfklmd37NixRneEWOSJWjwxbE2ccSNLTdkrEg34t5zvMZpsK8nmZSOXuSGdXFhOq3Zpy+/E0XG/ahzug/LQYlxWV7qSTtQ3WnbxKxH8uEau/Fbalkm5MPTJyawwzpWuFdISTze4PPt45T78WpP5/uXBzdRCjUbI10HPaAjnbhUMgxQVvR3kpKtjhZUdMPPD2/fvpLX+51Z8UPzrKzqntuiMnLfbDDZKYYUyXuzzLlNky0R3y1hgTM6bkxHU/7fhNS4cW3PeZ4BXPdu8l3toGxIuPfn1VsvJEiGTylnhXWeFT/QLU3kKqDUvfJaMYzQ0oktVPZIS9fHWcPVVkdvbcSV0Vjemj51YOqL5JaFCNtDZ+mCCJvJVZms7gWQSB0GUduVzq/mUmw05fmFnjBxJAszmHmfHH95jOGiuONQYivlrJSA9kxmuM+qR/MlNiVXpMw8Qo6BNa1qOmusj7i1u/vFOO2bMLLx1vPtxsa4qLGdxDUTue3Gy7hfzLovQ+frxCTWPZUN9HtsKLgxQy6xqEBRoxeU+9q7cNioFTV5e0FHEFX6WBgYG/7p7l2JrMgoLTzy68kS+objRzYwaKtcyesSxP5ccE5osSzSJMcQy/f8XpyIxIPOFfoG7zgiTMVus2qDSGHJo0ukBqonN+8pah/ePEjQhLt7P8c+ja77kDaUURNrUiQOzpR3RgW3My1Vw9EVGVhsFl1bWj19/+OWxK9qArrk6BdgPxPG/xAnjaArqgQj9Wp418i6ZXffR2TuuQ7Qt2viCTygH9CsSAFlWsJ7PckY9PmtyMndaeTcfYm3ASvNKuDPlaCq+8S2NGqREXqj5VNNWOoyWRM+CXtNjxhjgtsnTIG5AnEzEQ5w5C26ZOQskfBo9YQOKlIZJMA4eyx5hwflQfN+VyfXlI3zojVsXbVNfkSuUkFeskdcpWxUzggykcqXOujlnRg3NELGUvn5htfPSAd4DWBZUb6ORcMMquGkinImg2SGfn9d/N3wyj8k5pcI2kaLj3MaL7T/mlx2IghS58W8uJBAoIpgZl7+qhrq0Y1lTZYdAtlCja/8bf8w8GgCfkfoaLg+eJ92mXcfaIuvZsmakzG+6ZrVj6ERPQzq8kO994i0+vJYq3gboWhhVjRkBiGpbU4N/ik6jxS0/Da5bsdu8G68vDYgO17B7rmPjXvBHmtWFtjfQwAyRQZ9gWDX4KtCcIITch/ZLOfA7uRxPu9EHiBwwxm9cN/t4OpkFVQqo8xBpjPuCf2/YuRmVGdRMGfX7b0O+ZbR+kY1CTW+gZS1O7Yw2+AXkhm8w3ksKHVndPaiQ3wYGDu7x4syUT/ZTgrWeBlOFRGcfgcQ9ap6F77HZf2w0OMDkebg8qvHB6jM499Fvcwvv/q/FpCOSw==')).decode('utf-8')  # Complete embedded interface


def json_text(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


def stuff(data: bytes) -> bytes:
    """Transport quoting only. Preserve every byte, including spaces and ESC.

    The inherited native word boundary is byte 32. Quoting that byte INSIDE
    framed payloads prevents its word join from collapsing file whitespace.
    Text outside frames retains exactly the ordinary interact() behavior.
    """
    return data.replace(bytes([ESC]), bytes([ESC]) + b'E').replace(b' ', bytes([ESC]) + b'S')


def unstuff(data: bytes) -> bytes:
    out = bytearray()
    i = 0
    while i < len(data):
        if data[i] != ESC:
            out.append(data[i])
            i += 1
            continue
        if i + 1 >= len(data) or data[i + 1] not in (69, 83):
            raise ValueError('Incomplete or unknown byte escape')
        out.append(ESC if data[i + 1] == 69 else 32)
        i += 2
    return bytes(out)


def pack_part(data: bytes, *, role='assistant', kind='file', name='artifact.bin', mime='application/octet-stream') -> bytes:
    """Public boundary format usable by lessons and eventual native output.

    Lengths are lengths of QUOTED metadata and payload, not character counts.
    Delimiters inside files cannot close a part because payloads are length-read.
    """
    if role not in ('user', 'assistant') or kind not in ('text', 'file', 'audio', 'video'):
        raise ValueError('Unsupported part role or kind')
    metadata = stuff(json_text({'protocol': PROTOCOL, 'role': role, 'kind': kind,
                               'name': name, 'mime': mime, 'n_bytes': len(data)}).encode('utf-8'))
    payload = stuff(data)
    return (PART_START + b' ' + str(len(metadata)).encode('ascii') + b':' + metadata
            + b' ' + str(len(payload)).encode('ascii') + b':' + payload + b' ' + PART_END)


def _read_sized(raw, pos):
    colon = raw.find(b':', pos)
    if colon < 0 or colon == pos or not raw[pos:colon].isdigit():
        raise ValueError('Missing byte length')
    count = int(raw[pos:colon])
    end = colon + 1 + count
    if end > len(raw):
        raise ValueError('Incomplete framed payload')
    return raw[colon + 1:end], end


def unpack_part(raw: bytes, start=0):
    if raw[start:start + len(PART_START) + 1] != PART_START + b' ':
        raise ValueError('Missing part sentinel')
    encoded_meta, pos = _read_sized(raw, start + len(PART_START) + 1)
    if raw[pos:pos + 1] != b' ':
        raise ValueError('Missing metadata boundary')
    encoded_data, pos = _read_sized(raw, pos + 1)
    if raw[pos:pos + len(PART_END) + 1] != b' ' + PART_END:
        raise ValueError('Missing end sentinel')
    meta = json.loads(unstuff(encoded_meta).decode('utf-8'))
    data = unstuff(encoded_data)
    if not isinstance(meta, dict) or meta.get('protocol') != PROTOCOL:
        raise ValueError('Unknown boundary protocol')
    if meta.get('role') not in ('user', 'assistant'):
        raise ValueError('Unknown segment role')
    if meta.get('kind') not in ('text', 'file', 'audio', 'video'):
        raise ValueError('Unknown segment kind')
    if type(meta.get('n_bytes')) is not int or meta['n_bytes'] != len(data):
        raise ValueError('Payload length does not match metadata')
    if not isinstance(meta.get('name'), str) or not isinstance(meta.get('mime'), str):
        raise ValueError('Invalid file metadata')
    return meta, data, pos + len(PART_END) + 1


def split_parts(raw: bytes):
    """Separate strict parts from prose; never blindly delete token-like text.

    A malformed/incomplete frame remains in a text or raw-byte fallback part.
    The caller, not this parser, suppresses source-role upload echoes.
    """
    result = []
    cursor = scan = 0
    while True:
        start = raw.find(PART_START + b' ', scan)
        if start < 0:
            break
        try:
            meta, data, end = unpack_part(raw, start)
        except (ValueError, UnicodeError, json.JSONDecodeError, OverflowError):
            scan = start + len(PART_START)
            continue
        if start > cursor:
            result.append((None, raw[cursor:start]))
        result.append((meta, data))
        cursor = scan = end
    if cursor < len(raw):
        result.append((None, raw[cursor:]))
    return result


def safe_name(name):
    name = name.replace('\\', '/').split('/')[-1]
    name = ''.join(ch for ch in name if ord(ch) >= 32 and ch != '\x7f')
    return name if name not in ('', '.', '..') else 'artifact.bin'


def safe_mime(mime):
    # Untrusted artifacts are downloads; only passive audio/video are previewed.
    return mime if mime and all(ch.isalnum() or ch in '/.+-' for ch in mime) else 'application/octet-stream'


class DataLock:
    """A filesystem lock prevents two server processes sharing one checkpoint."""
    def __init__(self, path):
        self.file = open(path, 'a+b')
        try:
            if os.name == 'nt':
                import msvcrt
                self.file.seek(0)
                self.file.write(b'0')
                self.file.flush()
                self.file.seek(0)
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError):
            self.file.close()
            raise RuntimeError('This service-data directory is already held by another resident mind. Use one server worker.')

    def close(self):
        if os.name == 'nt':
            import msvcrt
            self.file.seek(0)
            msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
        self.file.close()


class Store:
    """Presentation data only. No conversation/history replays into the mind."""
    def __init__(self, directory):
        self.directory = directory
        self.guard = threading.RLock()
        self.db = sqlite3.connect(directory / 'chat.sqlite3', check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS chats(id TEXT PRIMARY KEY,title TEXT NOT NULL,updated_at REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,chat_id TEXT NOT NULL,role TEXT NOT NULL,
                parts TEXT NOT NULL,status TEXT NOT NULL,created_at REAL NOT NULL,job_id TEXT,
                verdict TEXT,error TEXT,raw_url TEXT,project_url TEXT);
            CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,chat_id TEXT NOT NULL,client_id TEXT UNIQUE NOT NULL,
                status TEXT NOT NULL,prompt TEXT NOT NULL,uploads TEXT NOT NULL,created_at REAL NOT NULL,
                error TEXT,verdict TEXT);
            CREATE TABLE IF NOT EXISTS artifacts(id TEXT PRIMARY KEY,path TEXT NOT NULL,name TEXT NOT NULL,
                mime TEXT NOT NULL,size INTEGER NOT NULL);
        ''')
        self.db.commit()

    def execute(self, sql, params=()):
        with self.guard:
            cursor = self.db.execute(sql, params)
            self.db.commit()
            return cursor

    def rows(self, sql, params=()):
        with self.guard:
            return [dict(row) for row in self.db.execute(sql, params).fetchall()]

    def one(self, sql, params=()):
        rows = self.rows(sql, params)
        return rows[0] if rows else None

    def chat(self, chat_id):
        chat = self.one('SELECT * FROM chats WHERE id=?', (chat_id,))
        if not chat:
            raise HTTPException(404, 'Conversation not found')
        messages = self.rows('SELECT * FROM messages WHERE chat_id=? ORDER BY created_at,rowid', (chat_id,))
        for msg in messages:
            msg['parts'] = json.loads(msg['parts'])
        chat['messages'] = messages
        return chat

    def new_chat(self, title='New conversation'):
        cid = uuid.uuid4().hex
        self.execute('INSERT INTO chats VALUES(?,?,?)', (cid, title, time.time()))
        return self.chat(cid)

    def artifact(self, data, name, mime):
        aid = uuid.uuid4().hex
        relative = 'artifacts/' + aid
        path = self.directory / relative
        temporary = path.with_suffix('.tmp')
        temporary.write_bytes(data)
        os.replace(temporary, path)
        name, mime = safe_name(name), safe_mime(mime)
        self.execute('INSERT INTO artifacts VALUES(?,?,?,?,?)', (aid, relative, name, mime, len(data)))
        kind = 'audio' if mime in ('audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/webm', 'audio/mp4', 'audio/flac') else (
            'video' if mime in ('video/mp4', 'video/webm', 'video/ogg') else 'file')
        return {'kind': kind, 'name': name, 'mime': mime, 'size': len(data), 'url': '/api/artifacts/' + aid}

    def response_parts(self, raw, input_prefix=b''):
        parts = []
        project_files = []
        if input_prefix and raw.startswith(input_prefix):
            # The whole source prefix was authored by the user, even when it
            # contains an assistant-role frame as a lesson or quoted example.
            chunks = [(meta, data) for meta, data in split_parts(input_prefix) if meta is None]
            chunks.extend(split_parts(raw[len(input_prefix):]))
        elif input_prefix:
            # An unexpected prefix is not permission to classify echoed data
            # as model-generated artifacts. Keep everything in raw fallback.
            chunks = [(None, raw)]
        else:
            chunks = split_parts(raw)
        for meta, data in chunks:
            if meta and meta['role'] == 'user':
                continue  # Do not pass upload echoes off as newly generated files.
            if meta and meta['kind'] != 'text':
                part = self.artifact(data, meta['name'], meta['mime'])
                parts.append(part)
                project_files.append((meta['name'], data))
                continue
            try:
                text = data.decode('utf-8')
            except UnicodeDecodeError:
                parts.append(self.artifact(data, (meta or {}).get('name', 'response-part.bin'),
                                           (meta or {}).get('mime', 'application/octet-stream')))
            else:
                if text.strip():
                    if parts and parts[-1]['kind'] == 'text':
                        parts[-1]['text'] += text
                    else:
                        parts.append({'kind': 'text', 'text': text})
        raw_url = self.artifact(raw, 'response.bin', 'application/octet-stream')['url']
        project_url = None
        if len(project_files) > 1:
            buffer = io.BytesIO()
            used = set()
            with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
                for name, data in project_files:
                    # Preserve safe relative project paths, never extract or execute.
                    path = name.replace('\\', '/')
                    chunks = [''.join(ch for ch in c if ord(ch) >= 32 and ch not in ':\x7f') for c in path.split('/')]
                    path = '/'.join(c for c in chunks if c not in ('', '.', '..'))
                    path = path or 'artifact.bin'
                    original = path
                    duplicate = 1
                    while path in used:
                        duplicate += 1
                        path = str(duplicate) + '-' + original
                    used.add(path)
                    archive.writestr(path, data)
            project_url = self.artifact(buffer.getvalue(), 'project.zip', 'application/zip')['url']
        if not parts:
            parts = [{'kind': 'text', 'text': 'No separate response part was emitted. The complete returned bytes are available below.'}]
        return parts, raw_url, project_url


class Runtime:
    def __init__(self, directory: Path, password: str, secure_cookie: bool, mind_factory=None, oauth=None):
        self.managed = bool(os.environ.get('DATABASE_URL')) and mind_factory is None
        self.oauth = oauth
        if self.oauth is None and os.environ.get('MANUS_PROJECT_ID') and mind_factory is None:
            from managed_auth import ManagedAuth
            self.oauth = ManagedAuth()
        if not password and self.oauth is None:
            raise RuntimeError('Set MIND_HVP_PASSWORD or start service.py interactively to choose a private password.')
        directory.mkdir(parents=True, exist_ok=True)
        try:
            directory.chmod(0o700)
        except OSError:
            pass
        self.lock = DataLock(directory / '.resident.lock')
        self.directory = directory
        (directory / 'artifacts').mkdir(exist_ok=True)
        self.checkpoint = directory / 'mind-hvp.line'
        if self.managed:
            from managed_store import ManagedStore
            self.store: Any = ManagedStore(directory)
        else:
            self.store = Store(directory)
        self.password_hash = hashlib.sha256(password.encode('utf-8')).digest()
        self.secure_cookie = secure_cookie
        self.sessions = {}
        self.failed_logins = {}
        self.auth_guard = threading.RLock()
        self.submit_guard = threading.RLock()
        self.resident_guard = threading.RLock()
        self.mind_factory = mind_factory
        self.mind_module = None
        self.mind: Any = None
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix='mind-hvp-turn')
        self.busy = False
        self.cached_status = {'resident': False, 'busy': False, 'integrity': {'intact': None},
                              'signature': {}, 'protocol': PROTOCOL}
        self.ensure_resident()

    def ensure_resident(self):
        with self.resident_guard:
            if self.mind is not None:
                if self.managed and not self.store.is_resident():
                    raise RuntimeError('Resident ownership was lost; this instance must restart before another turn.')
                return True
            if self.managed and not self.store.acquire_resident():
                return False
            saved = self.store.read_checkpoint() if self.managed else None
            seed = ROOT / 'hcl-ai' / 'mind-hvp.line'
            if saved is not None:
                temporary = self.checkpoint.with_suffix('.tmp')
                temporary.write_bytes(saved)
                os.replace(temporary, self.checkpoint)
            elif not self.checkpoint.exists() and seed.exists():
                temporary = self.checkpoint.with_suffix('.tmp')
                shutil.copyfile(seed, temporary)
                os.replace(temporary, self.checkpoint)
            self._wake_native()
            return True

    def _wake_native(self):
        if self.mind_factory is None:
            # Root-aware imports. No host path, stories checkpoint or hosted AI.
            os.environ['MARVOSA_ROOT'] = str(ROOT)
            for path in (ROOT, ROOT / 'hcl-ai', ROOT / 'hcl-ai' / 'engine', ROOT / 'hcl-ai' / 'mind'):
                if str(path) not in sys.path:
                    sys.path.insert(0, str(path))
            mind_hvp = importlib.import_module('mind_hvp')
            self.mind_module = mind_hvp
            self.mind = mind_hvp.MindHVP(checkpoint=self.checkpoint)
        else:
            self.mind = self.mind_factory(self.checkpoint)
        if self.managed:
            self.mind.save()
            self.store.mirror_checkpoint(self.checkpoint)
        self.cached_status = self.status_snapshot()
        interrupted = 'Server stopped during this turn. It has not been automatically replayed; the last completed native checkpoint was loaded.'
        self.store.execute("UPDATE jobs SET status='failed',error=? WHERE status='running'", (interrupted,))
        self.store.execute("UPDATE messages SET status='failed',error=? WHERE role='assistant' AND status='running'", (interrupted,))
        self.store.execute("UPDATE messages SET status='failed',error=? WHERE role='assistant' AND job_id IN (SELECT id FROM jobs WHERE status='failed') AND status='queued'", (interrupted,))
        # Only not-yet-experienced queued turns resume. History is never replayed.
        for job in self.store.rows("SELECT id FROM jobs WHERE status='queued' ORDER BY created_at,rowid"):
            self.executor.submit(self.run_turn, job['id'])

    def status_snapshot(self):
        if self.mind is None:
            return self.cached_status
        return {'resident': True, 'busy': self.busy, 'integrity': self.mind.integrity(),
                'signature': {key: str(value) if isinstance(value, int) else value
                              for key, value in self.mind.memory.signature().items()},
                'protocol': PROTOCOL}

    def _native_bytes_turn(self, payload):
        if self.mind_module is None:
            return self.mind.bytes_turn(payload)  # Injection for transport-only checks.
        juj = self.mind_module.juj
        braid = tuple(juj.bytes_to_braid(payload))
        self.mind._train_native(braid)
        out = self.mind.generate_native(braid)
        self.mind.experience_cycle()
        sig = self.mind_module._hvp(out['braid'])
        raw = juj.hvp_to_bytes(sig, verify=True)
        self.mind.save()
        return raw, out['verdict']

    def run_turn(self, job_id):
        job = self.store.one('SELECT * FROM jobs WHERE id=?', (job_id,))
        if not job or job['status'] != 'queued':
            return
        self.busy = True
        self.cached_status = {**self.cached_status, 'busy': True}
        self.store.execute("UPDATE jobs SET status='running' WHERE id=?", (job_id,))
        self.store.execute("UPDATE messages SET status='running' WHERE role='assistant' AND job_id=?", (job_id,))
        try:
            if not self.ensure_resident():
                raise RuntimeError('The prior deployment is finishing its turn; this instance does not yet own the mind.')
            uploads = json.loads(job['uploads'])
            if uploads:
                frames = []
                for upload in uploads:
                    if self.managed:
                        self.store.restore_artifact(upload['path'])
                    content = (self.directory / upload['path']).read_bytes()
                    frames.append(pack_part(content, role='user', kind='file', name=upload['name'], mime=upload['mime']))
                # Attachments precede prose so the actual prompt remains the
                # active trailing context, just as in the existing front door.
                # Only text gets the existing native whitespace normalization.
                prompt = self.mind_module._enter(job['prompt']) if self.mind_module else tuple(' '.join(job['prompt'].split()).encode('utf-8'))
                prompt_bytes = bytes(prompt)
                payload = b' '.join(frames + ([prompt_bytes] if prompt_bytes else []))
                raw, verdict = self._native_bytes_turn(payload)
                input_prefix = payload
            else:
                result = self.mind.interact(job['prompt'])
                # interact() has already expanded verify=True. Reuse those
                # delivered UTF-8 bytes, avoiding a second processor inversion.
                raw, verdict = result['answer'].encode('utf-8'), result['verdict']
                input_prefix = ' '.join(job['prompt'].split()).encode('utf-8')
            if self.managed:
                self.store.mirror_checkpoint(self.checkpoint)
            parts, raw_url, project_url = self.store.response_parts(raw, input_prefix)
            self.store.execute("UPDATE messages SET parts=?,status='completed',verdict=?,raw_url=?,project_url=? WHERE role='assistant' AND job_id=?",
                               (json_text(parts), verdict, raw_url, project_url, job_id))
            self.store.execute("UPDATE jobs SET status='completed',verdict=? WHERE id=?", (verdict, job_id))
            self.store.execute('UPDATE chats SET updated_at=? WHERE id=?', (time.time(), job['chat_id']))
            self.cached_status = self.status_snapshot()
        except Exception as exc:
            # No automatic retry after experience may have changed the mind.
            error = type(exc).__name__ + ': ' + str(exc)
            self.store.execute("UPDATE jobs SET status='failed',error=? WHERE id=?", (error, job_id))
            self.store.execute("UPDATE messages SET status='failed',error=? WHERE role='assistant' AND job_id=?", (error, job_id))
        finally:
            self.busy = False
            self.cached_status = {**self.cached_status, 'busy': False}

    def close(self):
        # Native generation finishes; there is no wrapper response-step limit.
        self.executor.shutdown(wait=True)
        if self.mind is not None and (not self.managed or self.store.is_resident()):
            self.mind.save()
            if self.managed:
                self.store.mirror_checkpoint(self.checkpoint)
        self.store.db.close()
        self.lock.close()


def create_app(data_dir=None, password=None, secure_cookie=False, mind_factory=None):
    directory = Path(data_dir or os.environ.get('MIND_HVP_DATA_DIR', str(ROOT / 'service-data'))).resolve()
    origin_file = ROOT / 'service-origins.json'
    configured_origins = json.loads(origin_file.read_text('utf-8')) if origin_file.exists() else []
    if not isinstance(configured_origins, list) or not all(isinstance(value, str) for value in configured_origins):
        raise RuntimeError('service-origins.json must contain an explicit list of public origins')
    trusted_public_origins = {value.rstrip('/').lower() for value in configured_origins}
    preview_origin = os.environ.get('MANUS_ADDON_PREVIEW_PUBLIC_ORIGIN')
    if preview_origin:
        trusted_public_origins.add(preview_origin.rstrip('/').lower())
    oauth = None
    if os.environ.get('MANUS_PROJECT_ID') and mind_factory is None:
        from managed_auth import ManagedAuth
        oauth = ManagedAuth()

    @contextlib.asynccontextmanager
    async def lifespan(app):
        runtime = Runtime(directory, password if password is not None else os.environ.get('MIND_HVP_PASSWORD', ''),
                          secure_cookie, mind_factory, oauth=oauth)
        app.state.runtime = runtime
        try:
            yield
        finally:
            await asyncio.to_thread(runtime.close)

    app = FastAPI(title='Mind-HVP private service', lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)

    @app.middleware('http')
    async def headers(request, call_next):
        response = await call_next(request)
        response.headers['Cache-Control'] = 'no-store'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'no-referrer'
        ancestors = '' if oauth else "frame-ancestors 'none'; "
        if not oauth:
            response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self'; connect-src 'self'; " + ancestors + "base-uri 'none'; form-action 'self'"
        if secure_cookie:
            response.headers['Strict-Transport-Security'] = 'max-age=31536000'
        return response

    def runtime(request):
        return request.app.state.runtime

    def discard_attempt_uploads(rt, uploads):
        # These UUID paths were created only by this unaccepted request, not
        # by a lived turn. Never delete a source file, checkpoint or old chat.
        for upload in uploads:
            rt.store.execute('DELETE FROM artifacts WHERE path=?', (upload['path'],))
            (rt.directory / upload['path']).unlink(missing_ok=True)

    def require_origin(request):
        origin = request.headers.get('origin')
        if origin:
            parsed = urlsplit(origin)
            if (parsed.scheme not in ('http', 'https') or not parsed.netloc
                    or parsed.username is not None or parsed.password is not None
                    or parsed.path or parsed.query or parsed.fragment):
                raise HTTPException(403, 'Cross-site requests are not allowed')
            # Hosting may rebase Host to its internal listener. Public origins
            # come from our explicit site config, never client-forwarded headers.
            is_public = origin.lower() in trusted_public_origins
            is_direct = parsed.netloc.lower() == request.headers.get('host', '').lower()
            if not is_public and not is_direct:
                raise HTTPException(403, 'Cross-site requests are not allowed')
        if request.headers.get('sec-fetch-site') == 'cross-site':
            raise HTTPException(403, 'Cross-site requests are not allowed')

    def session(request, mutation=False):
        rt = runtime(request)
        if rt.oauth is not None:
            value = rt.oauth.session(request)
            if mutation:
                require_origin(request)
                if not hmac.compare_digest(request.headers.get('x-csrf-token', ''), value['csrf']):
                    raise HTTPException(403, 'Missing or invalid CSRF token')
            return value
        token = request.cookies.get('mind_hvp_session', '')
        with rt.auth_guard:
            value = rt.sessions.get(token)
            if not value or value['expires'] < time.time():
                rt.sessions.pop(token, None)
                raise HTTPException(401, 'Please sign in')
        if mutation:
            require_origin(request)
            if not hmac.compare_digest(request.headers.get('x-csrf-token', ''), value['csrf']):
                raise HTTPException(403, 'Missing or invalid CSRF token')
        return value

    @app.get('/')
    def home():
        html = UI_HTML
        if html is None:
            html = (ROOT / 'service-ui.html').read_text('utf-8')
        return HTMLResponse(html)

    @app.get('/health')
    def health(request: Request):
        rt = runtime(request)
        if rt.mind is None:
            rt.ensure_resident()
        field = getattr(rt.mind, 'H', None)
        return {'ok': True,
                'state_representation': type(field).__name__ if field is not None else None,
                'resident': rt.mind is not None}

    @app.get('/manus-routes.json')
    def routes_manifest():
        return {'routes': [{'path': '/', 'title': 'Mind-HVP'}]}

    @app.get('/favicon.ico')
    def favicon():
        return FileResponse(ROOT / 'site-icon.png', media_type='image/png')

    @app.get('/api/session')
    def get_session(request: Request):
        try:
            value = session(request)
        except HTTPException:
            return {'authenticated': False, 'oauth': runtime(request).oauth is not None}
        return {'authenticated': True, 'csrf': value['csrf'], 'oauth': runtime(request).oauth is not None}

    @app.post('/api/login')
    async def login(request: Request):
        require_origin(request)
        rt = runtime(request)
        if rt.oauth is not None:
            raise HTTPException(400, 'Use Continue with Manus to sign in to this published site')
        ip = request.client.host if request.client else 'local'
        body = await request.json()
        supplied = body.get('password') if isinstance(body, dict) else None
        if not isinstance(supplied, str):
            raise HTTPException(400, 'Password must be text')
        now = time.time()
        with rt.auth_guard:
            attempts = [stamp for stamp in rt.failed_logins.get(ip, []) if now - stamp < 60]
            if len(attempts) >= 5:
                raise HTTPException(429, 'Too many attempts; try again in a minute')
            if not hmac.compare_digest(hashlib.sha256(supplied.encode('utf-8')).digest(), rt.password_hash):
                rt.failed_logins[ip] = attempts + [now]
                raise HTTPException(401, 'Incorrect password')
            rt.failed_logins.pop(ip, None)
            old = request.cookies.get('mind_hvp_session')
            if old:
                rt.sessions.pop(old, None)
            token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
            rt.sessions[token] = {'csrf': csrf, 'expires': now + 28800}
        response = JSONResponse({'authenticated': True, 'csrf': csrf})
        response.set_cookie('mind_hvp_session', token, secure=secure_cookie, httponly=True,
                            samesite='strict', max_age=28800, path='/')
        return response

    @app.post('/api/logout')
    def logout(request: Request):
        session(request, mutation=True)
        rt = runtime(request)
        with rt.auth_guard:
            rt.sessions.pop(request.cookies.get('mind_hvp_session'), None)
        response = JSONResponse({'ok': True})
        response.delete_cookie('mind_hvp_session', path='/')
        if rt.oauth is not None:
            rt.oauth.clear(response)
        return response

    @app.get('/api/status')
    def status(request: Request):
        session(request)
        runtime(request).ensure_resident()
        return runtime(request).cached_status

    @app.get('/api/chats')
    def chats(request: Request):
        session(request)
        return {'chats': runtime(request).store.rows('SELECT * FROM chats ORDER BY updated_at DESC,rowid DESC')}

    @app.post('/api/chats')
    async def new_chat(request: Request):
        session(request, mutation=True)
        body = await request.json()
        title = body.get('title', 'New conversation') if isinstance(body, dict) else 'New conversation'
        if not isinstance(title, str):
            raise HTTPException(400, 'Title must be text')
        return runtime(request).store.new_chat(title or 'New conversation')

    @app.get('/api/chats/{chat_id}')
    def get_chat(chat_id: str, request: Request):
        session(request)
        return runtime(request).store.chat(chat_id)

    @app.get('/api/jobs/{job_id}')
    def get_job(job_id: str, request: Request):
        session(request)
        job = runtime(request).store.one('SELECT id,chat_id,status,error,verdict FROM jobs WHERE id=?', (job_id,))
        if not job:
            raise HTTPException(404, 'Turn not found')
        return {**job, 'job_id': job['id']}

    @app.post('/api/turn')
    async def turn(request: Request):
        session(request, mutation=True)
        rt = runtime(request)
        if not rt.ensure_resident():
            raise HTTPException(503, 'The prior deployment is finishing its turn. Please retry after the hosting handover.')
        # Transport has no app-selected file count or prompt-length limit.
        # Uploads spool to disk; the native organ receives one complete braid.
        async with request.form(max_files=sys.maxsize, max_fields=sys.maxsize, max_part_size=sys.maxsize) as form:
            prompt, chat_id, client_id = form.get('prompt', ''), form.get('chat_id'), form.get('client_id')
            if not isinstance(prompt, str) or not isinstance(chat_id, str) or not isinstance(client_id, str) or not client_id or len(client_id) > 191:
                raise HTTPException(400, 'prompt, chat_id and client_id are required text fields')
            rt.store.chat(chat_id)
            existing = rt.store.one('SELECT id,chat_id FROM jobs WHERE client_id=?', (client_id,))
            if existing:
                if existing['chat_id'] != chat_id:
                    raise HTTPException(409, 'This client turn ID belongs to another conversation')
                return {'job_id': existing['id']}
            uploads = []
            user_parts: list[dict[str, Any]] = [{'kind': 'text', 'text': prompt}] if prompt else []
            for upload in form.getlist('files'):
                if isinstance(upload, str) or not hasattr(upload, 'file'):
                    discard_attempt_uploads(rt, uploads)
                    raise HTTPException(400, 'files must be uploaded file parts')
                aid = uuid.uuid4().hex
                relative = 'artifacts/' + aid
                path = rt.directory / relative
                temporary = path.with_suffix('.upload')
                size = 0
                with temporary.open('wb') as target:
                    while True:
                        chunk = await upload.read(1024 * 1024)
                        if not chunk:
                            break
                        target.write(chunk)
                        size += len(chunk)
                os.replace(temporary, path)
                name = safe_name(upload.filename or 'attachment.bin')
                mime = safe_mime(upload.content_type or mimetypes.guess_type(name)[0] or 'application/octet-stream')
                rt.store.execute('INSERT INTO artifacts VALUES(?,?,?,?,?)', (aid, relative, name, mime, size))
                if rt.managed:
                    rt.store.persist_upload(relative)
                uploads.append({'name': name, 'mime': mime, 'size': size, 'path': relative})
                user_parts.append({'kind': 'file', 'name': name, 'mime': mime, 'size': size, 'url': '/api/artifacts/' + aid})
            if not prompt.strip() and not uploads:
                raise HTTPException(400, 'Write a message or attach a file')
            with rt.submit_guard:
                # Check again after slow uploads; a retry is never experienced twice.
                existing = rt.store.one('SELECT id,chat_id FROM jobs WHERE client_id=?', (client_id,))
                if existing:
                    discard_attempt_uploads(rt, uploads)
                    if existing['chat_id'] != chat_id:
                        raise HTTPException(409, 'This client turn ID belongs to another conversation')
                    return {'job_id': existing['id']}
                job_id, stamp = uuid.uuid4().hex, time.time()
                with rt.store.guard:
                    db = rt.store.db
                    try:
                        db.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?)',
                                   (job_id, chat_id, client_id, 'queued', prompt, json_text(uploads), stamp, None, None))
                        db.execute('INSERT INTO messages(id,chat_id,role,parts,status,created_at,job_id) VALUES(?,?,?,?,?,?,?)',
                                   (uuid.uuid4().hex, chat_id, 'user', json_text(user_parts), 'completed', stamp, job_id))
                        db.execute('INSERT INTO messages(id,chat_id,role,parts,status,created_at,job_id) VALUES(?,?,?,?,?,?,?)',
                                   (uuid.uuid4().hex, chat_id, 'assistant', '[]', 'queued', stamp, job_id))
                        chat = rt.store.one('SELECT title FROM chats WHERE id=?', (chat_id,))
                        title = (' '.join(prompt.split())[:64] or (uploads[0]['name'] if uploads else 'Conversation')) if chat['title'] == 'New conversation' else chat['title']
                        db.execute('UPDATE chats SET title=?,updated_at=? WHERE id=?', (title, stamp, chat_id))
                        db.commit()
                    except Exception:
                        db.rollback()
                        raise
                rt.executor.submit(rt.run_turn, job_id)
            return {'job_id': job_id}

    @app.get('/api/artifacts/{artifact_id}')
    def artifact(artifact_id: str, request: Request):
        session(request)
        rt = runtime(request)
        item = rt.store.one('SELECT * FROM artifacts WHERE id=?', (artifact_id,))
        if not item:
            raise HTTPException(404, 'File not found')
        path = (rt.directory / item['path']).resolve()
        if not path.is_relative_to((rt.directory / 'artifacts').resolve()):
            raise HTTPException(403, 'Invalid artifact path')
        if rt.managed and not path.is_file():
            try:
                path = rt.store.restore_artifact(artifact_id)
            except FileNotFoundError:
                raise HTTPException(404, 'Durable artifact bytes are missing')
        if not path.is_file():
            raise HTTPException(404, 'File is missing from service storage')
        passive = item['mime'] in ('audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/webm', 'audio/mp4', 'audio/flac', 'video/mp4', 'video/webm', 'video/ogg')
        return FileResponse(path, filename=item['name'], media_type=item['mime'],
                            content_disposition_type='inline' if passive else 'attachment')

    if oauth is not None:
        oauth.install(app)
    return app


def main():
    parser = argparse.ArgumentParser(description='Portable private Mind-HVP web service (one resident mind; no external AI)')
    parser.add_argument('--host', default='127.0.0.1', help='Default: local computer only; use a private network or HTTPS reverse proxy for remote access')
    parser.add_argument('--port', type=int, default=int(os.environ.get('PORT', '8765')))
    parser.add_argument('--data', default=os.environ.get('MIND_HVP_DATA_DIR', str(ROOT / 'service-data')))
    parser.add_argument('--secure-cookie', action='store_true', default=os.environ.get('MIND_HVP_SECURE_COOKIE') == '1', help='Required for access through an HTTPS endpoint')
    parser.add_argument('--cert', help='Optional TLS certificate for direct HTTPS')
    parser.add_argument('--key', help='Optional TLS private key for direct HTTPS')
    args = parser.parse_args()
    if bool(args.cert) != bool(args.key):
        parser.error('--cert and --key must be provided together')
    secure = args.secure_cookie or bool(args.cert)
    if args.host not in ('127.0.0.1', 'localhost', '::1') and not secure:
        parser.error('Remote binding requires --secure-cookie behind HTTPS, or --cert and --key. Do not send your private password over public HTTP.')
    password = os.environ.get('MIND_HVP_PASSWORD', '')
    if not password and not os.environ.get('MANUS_PROJECT_ID'):
        password = getpass.getpass('Choose the private chat password (not stored in this source): ')
    if not password and not os.environ.get('MANUS_PROJECT_ID'):
        parser.error('A private password is required')
    import uvicorn
    app = create_app(args.data, password, secure_cookie=secure)
    print('One resident Mind-HVP. New chats do not reset it. Every accepted turn is experience.')
    print('State and UI data:', Path(args.data).resolve())
    uvicorn.run(app, host=args.host, port=args.port, workers=1, proxy_headers=False,
                ssl_certfile=args.cert, ssl_keyfile=args.key, timeout_graceful_shutdown=None)


if __name__ == '__main__':
    main()
