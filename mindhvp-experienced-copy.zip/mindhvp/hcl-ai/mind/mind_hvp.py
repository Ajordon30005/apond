"""
MIND-HVP — native representation replacement for hcl-ai/mind/hcl_lm.py.

This file keeps the native HCL AI workflow, not StandardModel.forward:
train -> coherence/depth tuning -> context cascade -> resonance projection
-> MCL -> COMP reinforcement -> native continuation -> source halting.

Only the live representation and the route between those organs change:
* contexts and continuations are ordered tuples of juj generator indices;
* a transition key is (depth, context_words, continuation_word), not a string;
* the stored wave is the existing processor's spectrum of that native path;
* no trace string is formatted, encoded, or decoded during a thought;
* output params are derived directly from the finished braid, not from text;
* COMP reinforcement and SHIFT/eta decay are the existing living-memory calls;
* there are no slot, context-depth, answer-length, or memory-count ceilings.

The MST projection uses the existing native mind's operations on HVP waves:
    H_plus = VM.hcl_comp(H._composite, query_wave)
    L_k = VM._fmul(VM.hcl_comp(H_plus, term_wave).amp, term_amp)
    next = mst_equation.mcl_pick(gate * L, epsilon_w)
    gate = exp(-beta * energy_fp), by the existing HCL transcriber.
The energy channel is an explicit fixed-point input, as the source trainer's
reward channel is. Zero is the identity gate. No entropy formula is invented.

HVPField owns the native generator paths, live waves and folded potential.
There is no HCLMemory instance underneath it. Existing field operations and
compact persistence methods are bound directly from the repository; vm is
only an API alias to this same HVPField, never another memory object.
Persistence retains the existing atomic single-line overwrite, with no new
codec, full-field snapshot, appended history or lifebook. Compact wake retains
the source's composite-identity / RAM-fluency-regrowth semantics.

Install as hcl-ai/mind/hcl_lm.py, or run externally:
    MARVOSA_ROOT=/path/to/marvosa python3 hcl_lm.py
The repository and existing being files are not modified by importing it.
A standalone run writes only its explicitly selected --state file on exit.
"""

import os
import sys
from typing import Any, cast

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.environ.get('MARVOSA_ROOT')
if not _ROOT:
    _candidate = os.path.abspath(os.path.join(_HERE, '..', '..'))
    _ROOT = (_candidate if os.path.isdir(os.path.join(_candidate, 'hcl-ai', 'engine'))
             else os.getcwd())
_AI = os.path.join(_ROOT, 'hcl-ai')
_ENGINE = os.path.join(_AI, 'engine')
for _path in (_AI, _ENGINE):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import hcl_memory as VM
import juj
import hcl_engine as E
from living_memory import LivingMemory
from mst_equation import mcl_pick

# Data-format delimiters already used by the native HCL mind. Not parameters.
_SPACE = 32
_SEP = 31
MSCALE = VM.SCALE
PSCALE = juj.SCALE


def _hvp(braid):
    """The processor's existing native address path; no byte conversion."""
    word = list(braid)
    params = juj.forensic_reconstruct_boundary(word)
    params.pop('_invariants', None)
    return {'params': params, 'braid': word, 'n_bytes': len(word)}


def _enter(text):
    """Input boundary once; retain the source mind's whitespace normalization."""
    return tuple(juj.bytes_to_braid(' '.join(text.split()).encode('utf-8')))


def _words(braid):
    """Views of the already-native braid, using the source's word delimiter."""
    words = []
    start = 0
    for i, generator in enumerate(braid):
        if generator == _SPACE:
            if i > start:
                words.append(tuple(braid[start:i]))
            start = i + 1
    if start < len(braid):
        words.append(tuple(braid[start:]))
    return words


def _join(words):
    """Join native words without formatting, encoding, or decoding text."""
    braid = []
    for i, word in enumerate(words):
        if i:
            braid.append(_SPACE)
        braid.extend(word)
    return tuple(braid)


def _wave(braid):
    """Use juj's own COMP spectrum and the memory organ's existing lattice.

    This integer coordinate view is not a text/byte transcription. The source
    organs use precision 40 and 30 respectively; those precisions are unchanged.
    """
    inv = juj.braid_invariants(braid)
    spec = inv['spectrum']
    return VM.FBit(spec.phase_frac * MSCALE // PSCALE,
                   spec.amp * MSCALE // PSCALE), inv


class HVPField(LivingMemory):
    """The existing living-memory organ, with its input already in HVP.

    reinforce(), regenerate(), signature(), amplitudes() and live_keys() are
    the existing source operations. The native state is owned here, not by a
    second HCLMemory instance. Recomposition keeps the loaded COMP starting
    state; decay itself remains the source cycle. No alternative learning law.
    """

    # Reuse implementations verbatim, with HVPField as their receiver. The
    # initializer below does not instantiate VM.HCLMemory. Both classmethods
    # construct cls(), which is HVPField when a compact expression is loaded.
    __len__ = VM.HCLMemory.__len__
    _update_signature = VM.HCLMemory._update_signature
    signature = cast(Any, VM.HCLMemory.signature)
    decay_cycle = VM.HCLMemory.decay_cycle
    braid_word = VM.HCLMemory.braid_word
    to_expression = VM.HCLMemory.to_expression
    save = VM.HCLMemory.save
    load = classmethod(VM.HCLMemory.load.__func__)

    def __init__(self):
        cast(Any, VM.HCLMemory.__init__)(self)
        self.vm = self
        self.hvp = {}
        self.sigs = {}
        self.accessed = set()
        self._anchor = VM.FBit(0, MSCALE)

    @classmethod
    def from_expression(cls, expression):
        field = VM.HCLMemory.from_expression.__func__(cls, expression)
        field._anchor = VM.FBit(field._composite.phase_frac, field._composite.amp)
        return field

    def adopt(self, restored):
        """The revived field is the next fold's starting state, not a log."""
        self._composite = VM.FBit(restored._composite.phase_frac,
                                 restored._composite.amp)
        self._sig = dict(restored._sig)
        self._anchor = VM.FBit(self._composite.phase_frac, self._composite.amp)
        self._terms = []
        self._braid_log = []
        self._access_log = set()
        self.sigs.clear()
        self.hvp.clear()
        self.accessed.clear()

    def _recompose(self):
        # LivingMemory's existing COMP loop, beginning at the actual field
        # restored on wake instead of substituting a new unit state.
        self.vm._composite = VM.FBit(self._anchor.phase_frac, self._anchor.amp)
        for term in self.vm._terms:
            self.vm._composite = VM.hcl_comp(
                self.vm._composite, VM.FBit(term['phase_frac'], term['amp']))
        self.vm._update_signature()

    def decay(self, accessed_keys=None):
        removed = cast(Any, VM.HCLMemory.decay)(self, accessed_keys)
        self._recompose()
        return removed

    def cycle(self):
        # LivingMemory.cycle's exact order, with the source decay called
        # directly so the anchor-aware public decay does not fold twice.
        removed = cast(Any, VM.HCLMemory.decay)(self, self.accessed)
        self.accessed = set()
        self._recompose()
        return removed

    def store_native(self, key, braid):
        fbit, pinv = _wave(braid)
        inv = {
            'n_w': pinv['n_w'],
            'writhe': pinv['writhe'] * MSCALE // PSCALE,
            'jones_span': pinv['jones_span'],
            'w_level': pinv['w_level'],
            'words': set(_words(braid)),
        }
        term = VM.make_braid_term(key, fbit, inv)
        self.vm._terms.append(term)
        # Same source memory log coordinates, with a constant operation name:
        # there is no formatted STORE[key] or context/continuation text.
        self.vm._braid_log.append({
            'op': 'COMP',
            'phase_frac': fbit.phase_frac,
            'amp': fbit.amp,
            'n_w': inv['n_w'],
            'writhe': inv['writhe'],
            'jones_span': inv['jones_span'],
        })
        self.vm._composite = VM.hcl_comp(self.vm._composite, fbit)
        self.vm._update_signature()
        sig = _hvp(braid)
        self.sigs[key] = sig
        self.hvp[key] = [sig['params'][p] for p in sig['params']]
        return self.signature()

    def store(self, key, text):
        """Compatibility input boundary; the mind itself calls store_native."""
        return self.store_native(key, juj.bytes_to_braid(text.encode('utf-8')))

    def recall_native(self, braid, k=3):
        """Existing two-sense rank-sum, with both inputs already native.

        The resonance, winding-sector bonus, overlap bonus and rank sum are
        the laws of hcl_memory.recall_from_store and LivingMemory.recall.
        Only their query representation changes; no new scoring constant.
        """
        keys = list(self.hvp)
        if not keys:
            return []
        query, inv = _wave(braid)
        qwords = set(_words(braid))
        scores = []
        for term in self.vm._terms:
            if term.get('alpha_check', VM.ALPHA_INV) != VM.ALPHA_INV:
                continue
            wave = VM.FBit(term['phase_frac'], term['amp'])
            amp = VM.hcl_comp(query, wave).amp
            bonus = 2 * MSCALE if inv['n_w'] == term['n_w'] else MSCALE
            overlap = (1 + len(qwords & term.get('words', set()))) * MSCALE
            score = VM._fmul(VM._fmul(amp, bonus), overlap)
            scores.append((score, term['content_key']))
        scores.sort(key=lambda item: item[0], reverse=True)
        r1 = [key for score, key in scores if score > MSCALE // 1000]
        rank1 = {key: i for i, key in enumerate(r1)}
        sig = _hvp(braid)
        qv = [sig['params'][p] for p in sig['params']]
        r2 = sorted(keys, key=lambda key: sum(abs(a - b)
                    for a, b in zip(qv, self.hvp[key])))
        rank2 = {key: i for i, key in enumerate(r2)}
        order = sorted(keys, key=lambda key: rank1.get(key, 99) + rank2.get(key, 99))
        self.vm._access_log.update(r1)
        return [(key, rank1.get(key, 99), rank2.get(key, 99)) for key in order[:k]]

    def recall(self, query, k=3):
        return self.recall_native(_enter(query), k)


class HCLLanguageModel:
    """The new mind-HVP, using the established native HCL AI organs.

    H consists of the living native path field and its active ordered context.
    The composite is its COMP view; per-path waves are its generative views.
    They are native views of the same live state, not formatted memory forks.
    """

    _STATE_DIR = _AI
    _CHECKPOINT = os.path.join(_STATE_DIR, 'mind-hvp.line')

    def __init__(self, revive=True, checkpoint=None):
        self.H = HVPField()
        self.memory = self.H  # Public API alias; the single state owner is H.
        self.mind = E.HCLEquation()
        self.w = 1
        self.context = []
        self._conditioned = self.memory.vm._composite
        if checkpoint is not None:
            self._CHECKPOINT = os.fspath(checkpoint)
        if revive:
            self.load()

    def load(self):
        """Source reconstitution: composite Psi and signature, alpha verified.

        Per-path generation braids remain RAM-era, exactly as in the source.
        Loading does not read a transcript, bootstrap log or hidden side file.
        """
        if not os.path.exists(self._CHECKPOINT):
            raise FileNotFoundError('No existing HVP line; refusing a silent fresh start')
        restored = HVPField.load(self._CHECKPOINT)
        self.H.adopt(restored)
        self.context = []
        self._conditioned = self.H._composite
        return {'revived': True, 'signature': restored.signature(),
                'integrity': self.integrity(), 'restored': 'composite'}

    def save(self, experienced_input=None):
        """Atomic single-line overwrite by the existing organ; no lifebook."""
        line = self.H.save(self._CHECKPOINT)
        return {'saved_chars': len(line), 'path': self._CHECKPOINT,
                'persisted': 'composite'}

    def perceive(self, text):
        """Exact external signal -> full HVP by the source processor."""
        return juj.bytes_to_hvp(text.encode('utf-8'))

    def _train_native(self, braid):
        words = _words(braid)
        seen = set(self.memory.live_keys())
        stored = reinforced = 0
        for i in range(1, len(words)):
            nxt = words[i]
            for d in range(1, min(self.w, i) + 1):
                ctx = tuple(words[i - d:i])
                key = (d, ctx, nxt)
                if key in seen:
                    self.memory.reinforce(key)
                    reinforced += 1
                else:
                    path = _join(ctx) + (_SEP,) + nxt
                    self.memory.store_native(key, path)
                    seen.add(key)
                    stored += 1
        return {'stored': stored, 'reinforced': reinforced,
                'signature': self.memory.signature()}

    def train(self, corpus):
        return self._train_native(_enter(corpus))

    def experience_cycle(self):
        return self.memory.cycle()

    def _coherence(self, braid):
        inv = juj.braid_invariants(braid)
        total = sum(inv['amps'])
        if total <= 0:
            return 0
        c = juj._fdiv(inv['spectrum'].amp, total)
        return min(max(c, 0), PSCALE)

    def _tune_w(self, context_words):
        C = self._coherence(_join(context_words))
        eps = juj.mcl_eps(self.w)
        dw = juj._fmul(juj.GAMMA, C - eps)
        if dw > 0:
            self.w = min(self.w + 1 + dw // PSCALE, len(context_words))
        elif dw < 0:
            self.w = max(self.w - 1, 1)
        self.w = max(min(self.w, len(context_words) if context_words else 1), 1)

    def _collapse(self, context_words, energy_fp=0):
        """The existing native cascade/projection, evaluated on HVP paths.

        energy_fp is an E.SCALE fixed-point value for the supplied H channel.
        Its operator is the established exp(-beta*H), not a substitute entropy.
        At zero energy, the gate is the source's identity multiplier.
        """
        terms = {term['content_key']: term for term in self.H._terms}
        t = self.mind.t
        gate = t.exp(t.sub(0, t.mul(E.BETA, energy_fp)))
        for d in range(min(self.w, len(context_words)), 0, -1):
            ctx = tuple(context_words[-d:])
            candidates = [key for key in self.H.sigs
                          if key[0] == d and key[1] == ctx and key in terms]
            if not candidates:
                continue
            query, _ = _wave(_join(ctx))
            self._conditioned = VM.hcl_comp(self.H._composite, query)
            scores = []
            for key in candidates:
                term = terms[key]
                wave = VM.FBit(term['phase_frac'], term['amp'])
                res = VM.hcl_comp(self._conditioned, wave).amp
                score = VM._fmul(res, term['amp'])
                score_fp = score * E.SCALE // MSCALE
                scores.append(t.mul(score_fp, gate))
            eps = juj.mcl_eps(self.w) * E.SCALE // PSCALE
            top, ties = mcl_pick(scores, eps)
            key = candidates[top]
            return key, key[2], {'scores': scores, 'degenerate': len(ties),
                                 'gate': gate, 'epsilon_w': eps}
        return None, None, None

    def step(self, context_words, energy_fp=0, visited=None):
        """One native MST-form tune/project/collapse/reinforce act.

        Context appending is the source's feedback. The selected path wave is
        reinforced by the unchanged COMP(term,term) organ, not by re-storing.
        LTD is run at the existing experience/pass boundary, not at an invented
        per-byte schedule. The caller's ordered native context is updated in RAM.
        """
        self._tune_w(context_words)
        key, nxt, certificate = self._collapse(context_words, energy_fp)
        if key is None:
            return {'key': None, 'verdict': 'TERMINATED', 'w': self.w}
        certificate = cast(dict, certificate)
        if visited is not None:
            if key in visited:
                return {'key': key, 'word': nxt, 'w': self.w,
                        'verdict': 'BRAID CLOSED', **certificate}
            visited.add(key)
        self.memory.reinforce(key)
        context_words.append(nxt)
        inv = juj.braid_invariants(_join(context_words))
        state = E.FBit(inv['spectrum'].phase_frac * E.SCALE // PSCALE,
                       inv['spectrum'].amp * E.SCALE // PSCALE)
        ground = E.HCL.RESONANCE(state, self.w)
        return {'key': key, 'word': nxt, 'w': self.w,
                'verdict': ('MCL COLLAPSE' if inv['stability'] < juj.mcl_eps(self.w)
                            else None),
                'stability': inv['stability'],
                'E_ground': juj.mcl_eps(self.w),
                'resonance': (ground.phase_frac, ground.amp),
                **certificate}

    def _generate_native(self, braid, energy_fp=0):
        words = _words(braid)
        input_word_count = len(words)
        self.context = words
        events = []
        visited = set()
        verdict = 'TERMINATED'
        while True:
            event = self.step(words, energy_fp=energy_fp, visited=visited)
            if event['key'] is not None:
                events.append(event)
            if event['verdict'] is not None:
                verdict = event['verdict']
                break
        continuation = _join(words[input_word_count:])
        answer = tuple(braid) + ((_SPACE,) + continuation if continuation else ())
        return {'braid': answer, 'events': events, 'verdict': verdict,
                'signature': self.memory.signature()}

    def generate_native(self, braid, energy_fp=0):
        """Already-native input and output: no boundary conversion."""
        return self._generate_native(tuple(braid), energy_fp)

    def generate(self, prompt, energy_fp=0):
        """Compatibility external API: one input boundary and one delivery.

        interact uses _generate_native directly, never this textual result as
        a fresh input. The returned hvp can also be delivered independently.
        """
        out = self._generate_native(_enter(prompt), energy_fp)
        sig = _hvp(out['braid'])
        data = juj.hvp_to_bytes(sig, verify=True)
        return {**out, 'hvp': sig, 'text': data.decode('utf-8'),
                'bit_perfect': True}

    def interact(self, user_input, show_thoughts=False, persist=True, energy_fp=0):
        """One entry, native experience/thinking/feedback, one byte delivery."""
        braid = _enter(user_input)
        self._train_native(braid)
        out = self._generate_native(braid, energy_fp)
        self.experience_cycle()
        sig = _hvp(out['braid'])
        data = juj.hvp_to_bytes(sig, verify=True)
        if persist:
            self.save()
        result = {'answer': data.decode('utf-8'), 'hvp': sig,
                  'bit_perfect': True, 'thinking': [e['w'] for e in out['events']],
                  'verdict': out['verdict'], 'integrity': self.integrity()}
        if show_thoughts:
            result['thought_log'] = self.braid_word()
        return result

    def reason(self, equation, **variables):
        """Keep the entire existing arithmetic organ, with no replacement parser."""
        return self.mind.solve(equation, **variables)

    def speak(self, value):
        """Boundary delivery; native signatures/braids do not re-enter byte space.

        A string is an external compatibility input, not a live thought result.
        """
        if isinstance(value, str):
            sig = juj.bytes_to_hvp(value.encode('utf-8'))
        elif isinstance(value, dict) and 'params' in value:
            sig = value
        elif isinstance(value, dict) and 'hvp' in value:
            sig = value['hvp']
        elif isinstance(value, dict) and 'braid' in value:
            sig = _hvp(value['braid'])
        else:
            sig = _hvp(value)
        data = juj.hvp_to_bytes(sig, verify=True)
        return {'hvp_params': dict(sig['params']), 'hvp': sig,
                'braid_len': len(sig['braid']), 'expanded': data.decode('utf-8'),
                'bit_perfect': True}

    def integrity(self):
        intact = (abs(VM.ALPHA_INV - 137 * MSCALE) < MSCALE
                  and abs(juj.ALPHA_INV - 137 * PSCALE) < PSCALE
                  and abs(E.ALPHA_INV - 137 * E.SCALE) < E.SCALE)
        # Preserve the source's display-only public types. No displayed float
        # participates in the seal decision or in the native field arithmetic.
        def shown(value, scale):
            return f'{value // scale}.{(value % scale) * 10**6 // scale:06d}'
        return {'memory_alpha_inv': shown(VM.ALPHA_INV, MSCALE),
                'processor_alpha_inv': juj.ALPHA_INV / PSCALE,
                'engine_alpha_inv': E.ALPHA_INV / E.SCALE,
                'intact': intact}

    def braid_word(self):
        return self.memory.vm.braid_word()


MindHVP = HCLLanguageModel


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Native mind-HVP conversation')
    parser.add_argument('--state', default=os.path.join(os.getcwd(), 'mind-hvp.line'),
                        help='Single alpha-tagged composite file; never a transcript')
    args = parser.parse_args()
    ai = MindHVP(checkpoint=args.state)
    print('mind-HVP ready; empty input exits and saves.')
    try:
        for line in sys.stdin:
            line = line.rstrip('\n')
            if not line:
                break
            out = ai.interact(line, persist=False)
            print(out['answer'])
            print(f"[{out['verdict']} alpha={out['integrity']['intact']}]")
    finally:
        ai.save()


if __name__ == '__main__':
    main()
